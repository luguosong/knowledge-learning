# AI 模型

## 综述

模型比较必须保留基准版本、工具条件与评测环境。用户提供的 GLM 5.3 Flash 对比图中，Claude Haiku 5.5 在 8 行结果中的 7 行得分最高；GLM 5.3 Flash 仅在 GDPval-AA v2.1 略高，在 Humanity’s Last Exam 使用工具时与 Haiku 得分接近，在图示视觉推理测试上差距较大。Anthropic 官方发布页与图中 Haiku、GPT-6 Luna 的数值一致；图的原始发布者及 GLM 各项数值尚未全部核实。图注称 GLM 的 HLE 使用工具成绩由厂商自报，其余 GLM 成绩来自独立评测，并提醒评测环境可能不同；不能据此断言实际任务表现或性价比。翻译比较还必须保留语言方向、内容类型、实际模型版本与质量指标；综合能力榜、中译英成绩、同系列其他型号的成绩均不能直接证明截图服务的英译中排名。HardMTBench 的模型排名随测试集与指标变化，因此实际文本的比较仍需核查准确性、漏译与术语一致性。评测日期、模型发布年份与订阅服务名必须分别核对；DeepL Pro 不标识模型版本，DeepL 官方说明会持续部署新模型，2024 年对旧型号的盲测不能直接支持 2026 年的推荐优先级。讨论"本地部署"时必须先区分本体与复刻：Jev（TypeSafe AI）闭源、仅提供 API、未发布权重；社区所称"开源版 Jev"是 Convai Innovations 的 Laya（Apache 2.0，421M/322M 参数），CPU 即可推理，官方 GPU 基准为 T4 约 33 ms/题，并自带与 Jev 线路协议兼容的自托管服务。两者能力对比不存在同条件大样本中立实测：方向性结论为 Jev 在准确率、开箱校准（ECE 0.246 对 0.466）、选项顺序稳定性与高选项数（上限 255 选项）占优，Laya 在速度（约 6–7 倍）与本地成本占优，英文分类准确率不落下风；Laya 零样本 typed-decisions 低于多数类基线、需任务微调，开箱过自信需温度重拟合。社区级联方案（Laya 前置、低置信度升级 Jev）在 40 例中文实测中复现 Jev 准确率。 截至 2026-10-26，智谱官方仍将 GLM-5.3 列为旗舰，GLM-5.3-Flash/FlashX 属于当前产品线；FlashX 官方称推理速度达 200 tokens/s。下一代基座已在训练，方向为更大的有效规模、更长的原生上下文和原生多模态统一建模；完全自训练（Fully Self Training）是模型参与数据生成、任务环境构建与基础设施优化的研发愿景，目前仍有大量人工环节。2026-10-07 唐杰的新加坡国立大学讲座摘要继续强调长程智能体、后训练和训练环境扩展，以及 AI 帮助构建下一代 AI。GLM-5.5、GLM-6.0 的正式型号、具体参数量和发布日期尚未从本次一手资料核实，不能将媒体命名或时间预测当作发布事实。

## 2026-10-08 · GLM 5.3 Flash 与 Haiku 5.5、GPT-6 Luna 对比图总结
- **问**：用中文总结这张图。
- **答**：按图中数据，Claude Haiku 5.5 在多数项目领先；GLM 5.3 Flash 在 GDPval-AA v2.1 得分为 1641，略高于 Haiku 的 1620，但在另一项知识工作测试、推理、编程与视觉推理测试上低于 Haiku。GLM 的 HLE 使用工具成绩为 55.3%，接近 Haiku 的 57.4%；视觉推理为 16.3%，低于 Haiku 的 46.4% 和 Luna 的 29.1%，电脑操作成绩缺失，且图注提醒评测环境可能不同。
- **信源**：用户提供的对比图（原始发布者与链接未核实）；[一手] [Anthropic：Introducing Claude Haiku 5.5](https://www.anthropic.com/claude-haiku-5-5)（已核实图中 Haiku、Luna 数值）；[一手] [Z.ai：GLM-5.3-Flash 模型卡](https://huggingface.co/zai-org/GLM-5.3-Flash)（已核实官方模型卡存在并说明 HLE 使用工具的评测设置，数值位于图表，未逐项核实）；[一手] [Artificial Analysis：GLM 5.3 Flash](https://artificialanalysis.ai/models/glm-5-3-flash)（已核实评测页面及基准版本，当前提取的页面未展示各项数值）。

## 2026-10-08 · 英译中模型比较应保留哪些评测条件
- **问**：关联问题：如何判断截图中的服务哪款英译中最好？
- **答**：必须区分英译中与中译英，并核对内容类型、模型版本、评测日期与质量指标；同系列其他型号、综合能力榜和对旧型号的评测均不足以支持本题排名。DeepL Pro 是服务名，不能据此确定模型年份；HardMTBench 也未覆盖截图中的全部具体服务，因此不能给出十款服务的第一名。
- **信源**：[一手] [HardMTBench 原始论文](https://arxiv.org/html/2605.28315v1)；[一手] [DeepL：Understanding Model Types](https://developers.deepl.com/docs/translate/understanding-model-types)；[一手] [DeepL 发布商说明](https://www.deepl.com/zh/publisher)；[一手] [DeepL 2024 年模型与盲测发布页](https://www.deepl.com/en/blog/next-gen-language-model)。
- **更新**：2026-10-08
- **关联**：[[机器翻译#2026-10-08 · 截图中的翻译模型哪款英译中表现最好]]

## 2026-10-15 · Jev 能否本地部署与硬件要求
- **问**：Jev 这个模型可以本地部署吗？硬件要求是什么？
- **答**：Jev 本体闭源、仅 API、未发布权重，不能本地部署。可本地部署的是开源复刻 Laya（Apache 2.0）：三个检查点 421M/421M/322M 参数，下载约 808/808/647 MB。官方未标最低显存；CPU fp32 可跑（28 线程约 110 ms/题），CUDA 混合精度下 421M 权重约 0.9 GB，推算 4 GB 显存足够；官方 GPU 基准 T4（16 GB）约 33–40 ms/题；Apple/AMD MPS 约 30–37 ms/题；Windows 官方支持；微调可在 Kaggle 2×T4 完成。`laya-serve` 提供与 Jev 相同的 POST /v1/systemone 协议，Jev 客户端只需改 baseUrl。
- **信源**：[一手] [TypeSafe AI：Introducing System One Models and Jev](https://typesafe.ai/blog/introducing-system-one-models-and-jev)（已核实：无权重发布、仅 API 控制台）；[一手] [GitHub：NandhaKishorM/laya README](https://github.com/NandhaKishorM/laya)（已核实：检查点规模、各设备延迟、协议兼容）；[一手] [Hugging Face：convaiinnovations/laya 模型卡](https://huggingface.co/convaiinnovations/laya)（已核实：下载体积、T4 基准、Apache 2.0）；二手参考未核实：ZiCode 8 GB 显卡实测、36kr MLX 约 1 GB 内存运行

## 2026-10-15 · Laya 与 Jev 能力对比
- **问**：Laya 和 Jev 的能力对比？
- **答**：无同条件大样本中立实测；现有数字来自 Laya 作者汇总（Jev 侧为第三方公布，样本与提示词不同）、TypeSafe 自评（自定义工作流，参考答案为 LLM 均值非真值）与一份 40 例社区同输入实测。方向上 Jev 占优：准确率（同输入 78% 对 57%）、高选项数（banking77 0.870 对 0.492；Jev 上限 255 选项，Laya 约 20 选项后崩溃）、开箱校准（ECE 0.246 对 0.466）、选项顺序稳定性（翻转率 0.13 对 0.15–0.23）。Laya 占优：速度（T4 33 ms 对 236–276 ms，约 6–7 倍）、成本（本地免费、可微调、可自托管），英文分类不落下风（AG News 0.95 对 0.91；Emotion 0.60 对 0.48）。Laya 零样本 typed-decisions 为 0.362，低于多数类基线 0.461，微调至 0.766 后才与 Jev 的 0.727 可比（条件不对等）。社区级联（Laya 前置，置信度低于 0.60 升级 Jev）复现 Jev 的 78% 准确率，平均延迟约减半。
- **信源**：[一手] [NandhaKishorM/laya：BENCHMARKS.md](https://github.com/NandhaKishorM/laya/blob/main/BENCHMARKS.md)（Laya 侧全套自测数字与诚实限制；Jev 侧为第三方公布，作者自注"仅作参考"）；[一手] [TypeSafe AI：Introducing System One Models and Jev](https://typesafe.ai/blog/introducing-system-one-models-and-jev)（Jev 官方声明：70–500 ms、255 选项上限、自评条件与偏差声明）；[一手] [yibie/laya-jev-lab](https://github.com/yibie/laya-jev-lab)（第三方同输入 40 例中文工单实测与级联；样本小、作者自标答案）

## 2026-10-26 · 智谱下一代模型的最新动向
- **问**：智谱下一代模型的最新动向。
- **答**：截至 2026-10-26，下一代基座已在训练，官方方向为更大有效规模、更长原生上下文、原生多模态、长程自主任务，以及模型参与数据、环境与基础设施建设的完全自训练；这些属于研发方向，流程仍有大量人工环节。当前官方旗舰仍为 GLM-5.3，FlashX 官方称推理速度达 200 tokens/s；尚未从一手资料核实 GLM-5.5／GLM-6.0 的正式型号、具体参数量与发布日期。
- **信源**：[一手] [智谱 2026 年中期业绩公告](https://www.hkexnews.hk/listedco/listconews/sehk/2026/0831/2026083101540_c.pdf)（印刷页 18 至 20：下一代基座训练、数天任务目标、自训练愿景及人工环节）；[一手] [智谱 2026-09-13 配售与可转债公告](https://www1.hkexnews.hk/listedco/listconews/sehk/2026/0913/2026091300025.pdf)（印刷页 20 至 22：约 60% 净募资计划投向下一代基座、自训练与算力基础设施，未给出新旗舰型号或发布日期）；[一手] [新加坡国立大学：2026-10-07 唐杰讲座摘要](https://ai.nus.edu.sg/glms-road-to-agi-from-chat-to-agents/)（已核实活动日期与摘要，未获得演讲完整录像或讲稿，不能据此确认媒体所称万亿参数或 GLM-5.4/5.5 命名）；[一手] [智谱：GLM-5.3 文档](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.3)；[一手] [智谱：GLM-5.3-Flash/FlashX 文档](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-5.3-flash)；[一手] [Z.ai：GLM-5.3-Flash 发布说明](https://z.ai/blog/glm-5.3-flash?trk=article-ssr-frontend-pulse_little-text-block)（新基座、混合注意力架构及向更大模型扩展的声明）；[一手] [Z.ai 发布记录](https://docs.z.ai/release-notes/new-released)；[一手] [zai-org 官方模型仓库](https://huggingface.co/zai-org)。二手寻源线索：[每经 2026-09-01 业绩会报道](https://www.nbd.com.cn/articles/2026-09-01/4568516.html)、[快科技转载 2026-10-08](https://www.hstong.com/news/hk/detail/26100818550373922)；其中具体型号、发布日期与参数规模未在本次一手材料中核实。
