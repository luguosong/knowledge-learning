# AutoCAD

## 综述

AutoCAD 自动化有两条技术路线：**活体控制**运行中的 AutoCAD（完整版走 COM/ActiveX 自动化接口，Python 经 pywin32 调用；AutoCAD LT 无 COM 但 2024 版起支持 AutoLISP，可用 LISP 派发器注入命令），以及**无 AutoCAD 的 headless 文件处理**（ezdxf 库直接生成/编辑 DXF，跨平台）。MCP 生态分两条线：Autodesk 官方自 2027 版起在 AutoCAD 内置 Autodesk Assistant 并开始使用 MCP，官方 FAQ 确认部分 Autodesk MCP 服务器可作为独立能力从 Design and Make Marketplace 获取（市场内 AutoCAD 专属条目清单未逐项核实）；社区开源项目活跃，代表性项目 puran-water/autocad-mcp（LT 2024+，AutoLISP File IPC + ezdxf 双后端）、U-C4N/Autocad-MCP（COM + ezdxf，pip 安装，工具数最多）、zh19980811/Easy-MCP-AutoCad（COM，已停止维护）。基础使用方面：所有新图形都从图形样板（DWT）出发，样板预设单位制、标注标准、打印样式模式与初始视图，自带样板按 acad（英制）/acadiso（公制）、Named Plot Styles（命名打印样式）、3D（初始等轴测视图）命名区分，国内公制环境默认选 acadiso.dwt。学习路线方面：零基础入门以官方免费资源为主线，装软件有三条免费路径（桌面版试用 15 天、合格学生与教育者的教育访问一年免费且可按年续期、AutoCAD Web 浏览器版免费查看），随后按五阶段推进：界面与视图 → 精确 2D 绘图 → 注释与出图 → 块与效率 → 分方向（行业 2D／3D／自动化），主线项目用官方教程中心的六部分平面图教程。试用申请方面：全球站 trial-intake 表单可完整走通（用途→产品→登录→个人信息→提交），但手机验证网关向中国大陆手机号（实测 +86 电信号）发送验证码失败，两次重试同样报错，试用因此未开通；中国区站点（autodesk.com.cn）的试用组件持续卡在加载，账户管理页试用列表为空。图纸交换方面：“天正转 T3”指将天正图纸导出为天正 3 兼容格式，使缺少天正对象支持的软件能够读取；转换结果仍是 DWG 图纸，常以文件名中的 _t3 标识。图层与可见图形通常可以保留，但天正构件类型、专业参数和智能编辑能力不能视为完整保留；具体图层归属和属性须按转换工具、版本与导出设置核验。待解：Design and Make Marketplace 中 AutoCAD 专属官方 MCP 的具体条目与配置方式；社区项目在中文 Windows 与本地化版本上的兼容性。

## 2026-10-13 · AutoCAD 自动化操作 MCP 的官方与社区现状
- **问**：AutoCAD 有没有相关自动化操作的 MCP。
- **答**：有，官方与社区两条线。官方：AutoCAD 2027 起内置 Autodesk Assistant 并开始使用 MCP，官方 FAQ（2026-09 修订）确认部分 Autodesk MCP 服务器可作为独立能力经 Design and Make Marketplace 获取。社区：多个开源 MCP 项目，活体控制走 COM（完整版）或 AutoLISP 注入（LT 2024+），无 AutoCAD 时用 ezdxf 直接读写 DXF。
- **信源**：[一手] [Autodesk Assistant 官方页（FAQ：独立 MCP 服务器）](https://www.autodesk.com/solutions/autodesk-assistant)；[一手] [puran-water/autocad-mcp README](https://github.com/puran-water/autocad-mcp)；[一手] [U-C4N/Autocad-MCP README](https://github.com/U-C4N/Autocad-MCP)；[一手] [zh19980811/Easy-MCP-AutoCad README](https://github.com/zh19980811/Easy-MCP-AutoCad)；二手线索：AutoCAD 2027 产品发布公告（2026-03-25，autodesk.com，检索摘要称 Assistant "beginning to leverage MCP"，未直接打开）
- **关联**：[[AI 编程#2026-10-20 · 将 WASM 封装为 MCP 供 Agent 调用的可行性与形态]]

## 2026-10-14 · 新建图形选择样板（DWT）的含义与自带样板的区别
- **问**：使用 AutoCAD 新建文件时，让我选择样板是什么意思，选择不同样板有什么区别。
- **答**：样板＝图形样板文件（DWT），新图形从它复制单位、图层、标注与文字样式、布局及打印设置，样板本身不被改动。自带 8 个样板沿四个维度区分：单位制（acad＝英制、acadiso＝公制）、标注标准（ANSI/ISO）、打印样式模式（颜色相关 CTB／命名 STB）、初始视图（带 3D＝初始等轴测）。国内公制环境通常选 acadiso.dwt。
- **信源**：[一手] [About Drawings and Templates（AutoCAD 2026 帮助，样板保存的设置清单）](https://help.autodesk.com/view/ACD/2026/ENU/?caas=caas/documentation/ACDLT/2014/ENU/files/GUID-02979F86-385F-4A53-A3FB-7202F1225CDA-htm.html)；[一手] [AutoCAD 样板（Autodesk 支持文章，当前版自带样板清单，中文）](https://www.autodesk.com.cn/support/technical/article/caas/tsarticles/ts/a2FplfQ1RO2AiFuw1aeHn.html)；[一手] [AutoCAD 2022 Templates（acadiso.dwt 属性确认）](https://www.autodesk.com/support/technical/article/caas/tsarticles/ts/3jQpr3507YTptqWwl5ct8a.html)；[一手] [To Start a New Drawing（AutoCAD LT 2026 帮助）](https://help.autodesk.com/view/ACDLT/2026/ENU/?caas=caas/documentation/ACD/2014/ENU/files/GUID-9836C645-44B4-4EF8-B05A-66EFB2FE0DD2-htm.html)；[一手] [To Change Template Settings（QNEW 默认样板设置）](https://help.autodesk.com/view/ACDLTM/2026/ENU/?caas=caas/documentation/ACD/2014/ENU/files/GUID-BB840055-4B21-4E4A-9DFC-187D63B44F6D-htm.html)；[一手] [To Create a Drawing Template（自建样板）](https://help.autodesk.com/view/ACDLTM/2026/ENU/?caas=caas/documentation/ACD/2014/ENU/files/GUID-009D9EB3-DE3E-4107-BE48-56D907A7E9B7-htm.html)

## 2026-10-14 · 零基础学习 AutoCAD 的完整路线与官方免费资源
- **问**：零基础学习 AutoCAD 的完整教程。
- **答**：官方免费资源足够支撑零基础入门：装软件走三条免费路径（桌面版试用 15 天、合格学生/教育者的教育访问一年免费且可按年续期、AutoCAD Web 浏览器版），随后按五阶段推进——界面与视图 → 精确 2D 绘图（坐标、对象捕捉、图层）→ 注释与出图（标注、布局、打印 PDF）→ 块与效率（动态块、样板 DWT）→ 分方向（行业 2D／3D／自动化）；主线项目用官方教程中心的六部分平面图教程，每天约 1 小时，约 8–10 周可独立出图。
- **信源**：[一手] [AutoCAD 官方教程中心（CAD 基础 + 六部分项目 + 初学者必修）](https://www.autodesk.com/solutions/aec/autocad-tutorials)；[一手] [AutoCAD Quick Start Guide（15 讲入门学习路径）](https://www.autodesk.com/learn/ondemand/curated/autocad-quick-start-guide)；[一手] [AutoCAD 免费试用页（桌面版 15 天）](https://www.autodesk.com/products/autocad/free-trial)；[一手] [Autodesk 教育访问总览（一年免费、可年续）](https://www.autodesk.com/support/account/education/students-educators/overview)；[一手] [教育软件清单（含 AutoCAD）](https://www.autodesk.com/education/edu-software/overview)；[一手] [AutoCAD Web 官网（浏览器版）](https://web.autocad.com)

## 2026-10-14 · 中国大陆手机号申请 AutoCAD 试用的验证阻断（实测）
- **问**：用中国大陆手机号在官网申请 AutoCAD 免费试用，验证码收不到怎么办。
- **答**：全球站 trial-intake 表单可完整填写并提交，但最后一步手机验证的短信网关向 +86 号码（实测电信号）发送失败，报"无法向该号码发送验证码"，重试无效，试用不开通；中国区站点试用组件持续卡在加载。可行出路：联系 Autodesk 支持人工处理、改用可接收国际短信的号码，或学生/教育者改走教育访问（SheerID 验证，无需手机短信）。
- **信源**：[一手] 2026-10-14 实测 Autodesk trial-intake 流程与 manage.autodesk.com 账户页（本机浏览器操作记录）；[一手] [Autodesk 教育访问（无手机验证的替代路径）](https://www.autodesk.com/education/home)

## 2026-10-20 · 天正转 T3 的含义与图纸兼容目的
- **问**：天正转T3是什么意思；追问：原图层和对象信息会丢失吗。
- **答**：“转 T3”指将天正图纸导出为“天正 3”兼容格式，供缺少天正支持的 CAD 或算量软件读取，结果仍是 DWG 图纸，常见名称如“平面图_t3.dwg”。图层和可见图形通常可以保留，但天正专业对象转成普通图元后会丧失智能化专业特征，不能完整保留原构件类型、专业参数和关联编辑能力；具体图层归属及各项属性需按转换工具、版本和设置核验，应保留原始天正图，另导出一份用于交换。
- **信源**：[一手] [浩辰CAD：如何将CAD图纸转换成T3格式](https://www.gstarcad.com/cmsDetail/23254/)；[一手] [浩辰CAD看图王：天正图纸转换为标准DWG，并说明保留图层与可见内容（针对其产品）](https://yun.gstarcad.com/news/1072/)；[一手] [CAD快速看图：转t3官方教程](https://club.everdrawing.com/question/detail/14389)；[一手] [浩辰CAD：对象分解后丧失智能化专业特征（同类专业对象分解机制）](https://www.gstarcad.com/cmsDetail/20969/)；[一手] [北京市建筑工程设计有限责任公司原始专利CN116484482A，权利要求2：读取天正构件类型、几何及属性数据的翻模流程要求不转T3](https://patents.google.com/patent/CN116484482A/zh)
- **更新**：2026-10-20
