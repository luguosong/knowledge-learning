# Claude Code

## 综述

学习 Claude Code 的主线是**理论底座 → 单任务闭环 → 上下文与扩展 → 多任务编排 → 量化调优**。核心机制是模型通过工具收集上下文、采取行动、验证结果并循环；终端、IDE、桌面与网页是同一产品的不同入口。先练习“目标、范围、限制、可运行验收”，再掌握会话、CLAUDE.md／AGENTS.md、权限、skills、hooks、MCP 与 subagent；复杂任务才使用 worktree、并行会话、无头 CLI、CI 和 Agent SDK。subagent 适合边界清楚、可独立验收的调查、执行与审查；普通 subagent 从新上下文启动，由主 agent 传递任务与必要背景，返回报告，但默认不隔离文件。会话 fork 继承主对话历史，skill 的 `context: fork` 不继承；角色配置、恢复同一实例与持久记忆是三种不同机制。2026-10-07 官方文档确认默认嵌套为主会话以下 3 层、同时运行上限为 20，均可配置；这些值不是推荐任务规模；配置字段已核实至 15+（disallowedTools、permissionMode、maxTurns、effort、memory、isolation 等），定义位置五层优先级（托管 → 会话 → 项目 → 用户 → 插件），后台 subagent 仅保留精简工具集，agent teams 仍为实验特性。性能同时看一次通过率、人工干预、完成时间和每个通过任务的 token／费用；上下文是稀缺资源，子代理有独立用量，减少主上下文不保证降低总费用。2026-10-12 插件选型深化：按缺口组合开发流程、文档查询、语言服务器、界面设计与浏览器验证、专项审查；Superpowers 强调设计、计划、测试与验证，ECC（原 Everything Claude Code）提供更广的工程技能与配置，Feature Dev 用于已有仓库的新功能流程，三者存在职责重叠，应先选一种主流程。Context7 提供版本相关文档；语言服务器协议（Language Server Protocol，LSP）插件提供诊断与符号导航，需另装服务器程序，当前云会话不启动插件语言服务器。Frontend Design 与 Playwright 分别补界面实现和浏览器操作；PR Review Toolkit 提供按方面选择的审查代理。插件常驻上下文和多代理调用有用量代价；关注度和文档完整性不等于已测得的质量收益。没有适用于所有开发者的必装插件或外部 skill；以最小够用配置起步，先完善项目约定与可执行验证，再按反复出现的缺口增加扩展。默认 skill 名称与描述常驻，正文调用时加载且跨轮保留；手动调用型 skill 可避免未使用时的描述成本。选择时看启用组件、触发重叠与实际返工、耗时和用量，不设统一插件数量上限。待解：在 Java／React 项目中实测 subagent 的委派准确率、证据完整性、文件冲突与总用量，并比较 hooks、记忆、worktree、模型选择与插件组合的收益。2026-10-15 将工具闭环用于 PDF 翻译：个人先用 Claude Code 与专用 Skill，程序化批处理可用官方 Claude Agent SDK；agent 处理术语、翻译和审校，固定工具负责解析、排版与完整性检查。第三方 translate-book 采用 Markdown 重排，不能等同于保留原 PDF 版式；完整流程质量仍需实测。2026-10-18 补充 3 月 31 日泄露事件的源码研究入口：ChinaSiro/claude-code-sourcemap 保存 v2.1.88 的 source map 还原结果；sanbuphy 原 claude-code-source-code 已改名 learn-coding-agent，当前以架构研究材料为主；instructkr/claw-code 已迁至 ultraworkers/claw-code，以 Rust 为主且作者定位为研究展品；Kuberwastaken/claude-code 已改名 claurst，作者声明为按行为规格独立重写的 Rust 编程代理。必须区分源码存档、第三方分析与独立实现；存档公开可见不代表 Anthropic 已授予开源许可。2026-10-18 补充文档站获取方式：未找到官方公开的完整站点工程仓库；官方提供 llms.txt、递归语言索引和 .md 正文导出。实测 llms-full.txt 为 228 页英文合集，递归索引共 12 种语言、2,736 页，简体中文为 228 页；全部指索引列出的公开正文，图片／视频文件与站点工程需另行处理，不能把正文导出等同于原始站点源码。

## 2026-09-21 · Claude Code subagent 的使用、配置与执行原理
- **问**：详细讲解 Claude Code 中 subagent 的使用方法、配置方式、执行过程以及原理。追问：深入学习讲解 Claude Code 中的 subagent 用法。
- **答**：subagent 是拥有独立上下文、指令和工具配置的委托执行实例；普通实例不继承主对话历史，应以目标、范围、必要背景、约束与证据要求定义任务，并由主 agent 综合结果、完成验收。按 2026-10-07 官方文档，应区分普通 subagent、继承历史的会话 fork、skill 的隔离执行、恢复同一实例与持久记忆；上下文隔离不等于文件隔离或总费用降低。
- **历史结论（已被 2026-10-07 修正，具体修正见下）**：subagent 是由主对话派生、拥有独立上下文窗口的专职 agent，核心动机是隔离上下文污染（挤占预算、稀释注意力、推高成本）。执行：主 agent 依据各代理 description 决定委派 → Agent tool 派生 → 子代理冷启动（自身 system prompt + 任务消息 + CLAUDE.md + git 快照，不继承对话历史）→ 工具循环（两道工具过滤器 + 独立权限，提示上浮主会话）→ 输出扫描防提示注入 → 回传摘要 + agent ID（可用 SendMessage 带全历史续聊，保留热 prompt cache）。默认 3 层嵌套、20 并发；fork（/subtask）是唯一继承父历史的例外。配置：.claude/agents/（项目）与 ~/.claude/agents/（用户）下的 Markdown + frontmatter，仅 name、description 必填，description 驱动自动委派，model 解析顺序为 调用参数 → frontmatter → CLAUDE_CODE_SUBAGENT_MODEL → 主对话模型；缺 name/description 的文件被静默跳过。使用：自动委派（最常用）、@-mention（保证触发）、claude --agent <name>（整机替换）；内置 Explore（只读探索）/Plan（计划调研）/general-purpose。
- **校正与深化**：
  - 启动上下文存在例外：Explore 与 Plan 跳过 CLAUDE.md 和 git status；自定义代理可以用 `omitClaudeMd` 跳过用户、项目与本地 CLAUDE.md。普通代理不继承主对话已读文件、已调用 skill 的内容或主会话 auto memory；关键任务背景必须明确传递。
  - 交互式 CLI 中，自然语言命名由模型决定是否委派，@ 选择 agent 保证调用该角色；`--agent` 将主会话配置为该角色，`--agents` 定义本次会话可用的角色。`/agents` 从 v2.1.198 起只打印创建／维护提示；v2.1.197 及以前提供交互界面。
  - 当前默认嵌套深度 3、同时运行上限 20 已重新核实；分别由 `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH` 与 `CLAUDE_CODE_MAX_CONCURRENT_SUBAGENTS` 控制。并发限制约束 Agent tool 新派生；手动 fork、恢复实例和 ultracode 等存在例外，不能概括为绝对上限。
  - 模型通常依次取本次调用参数、代理定义、`CLAUDE_CODE_SUBAGENT_MODEL`、主会话模型；`CLAUDE_CODE_SUBAGENT_MODEL_FORCE=1` 可强制覆盖，fork 等仍有例外。不要把 Explore 固定理解为 Haiku；当前文档按主模型与接入方式定义其模型。
  - 前台执行阻塞主会话，后台执行允许继续工作；当前交互式 fork mode 默认开启并使新派生在后台运行。后台权限请求会显示在主会话；`/tasks` 用于查看和管理。后台不是取消权限检查。
  - 每次新调用建立新实例；恢复有 ID 的原实例可保留其历史，Explore 与 Plan 当前是一次性代理，不能恢复。`memory` 才用于跨会话持续记录；角色文件本身不保存历次任务历史。
  - 会话 `/subtask` 继承完整历史，skill 的 `context: fork` 创建独立上下文且不继承历史。`skills` 预加载完整 skill 内容，但不等于可访问 skill 的白名单。
  - 默认共用工作目录；并行写代码应划分文件所有权，必要时用 `isolation: worktree`。worktree 默认从仓库默认分支创建，可用 `worktree.baseRef: head` 从当前提交创建；未提交改动不会因此自动复制。
  - 只读审查示例使用 `tools: Read, Grep, Glob`。仅移除 Write／Edit 仍可能通过 Bash 或 MCP 写入；启用 `memory` 会自动增加 Read／Write／Edit。工具可用性、权限审批与文件隔离应分别考虑。
  - 原“输出扫描防提示注入”表述过强：扫描转义部分仿冒标记并标注指令形态，不判定内容是否恶意，也不能代替权限或沙箱。报告应带文件位置、触发条件、验证结果与未核实项；摘要不是正确性证明。
  - 定义位置共五层，优先级为托管 `.claude/agents/` → `--agents` 会话级 → 项目 → 用户 → 插件 `agents/`；目录递归扫描，嵌套项目目录中同名定义以离工作目录最近者为准；格式缺陷文件被静默跳过，可用 `claude plugin validate <dir>` 检查。
  - 字段全景（15+）：`disallowedTools` 先于 `tools` 应用，`Bash(git push *)` 类条目移除整个工具；`permissionMode` 在主会话处于 bypassPermissions/acceptEdits/auto 时被忽略，子代理不能自声明 bypassPermissions；`maxTurns` 截断输出并标记 partial、可续；`effort`（low/medium/high/xhigh/max）；`memory`（user/project/local，注入 MEMORY.md 前 200 行或 25 KB）；`mcpServers`（内联定义需目录信任）；`hooks`（Stop 映射为 SubagentStop）；`isolation: worktree`；`background`；`initialPrompt`；`experimental.cacheTtl`（5m/1h）；`skills` 不能预载 `disable-model-invocation: true` 的技能。
  - 所有代理 description 合计超 15,000 tokens 触发启动警告——description 是委派路由表，数量与长度都有代价。
  - 后台 subagent 仅保留精简内置工具集（Read/Grep/Glob/LSP/Bash/PowerShell/Edit/Write/NotebookEdit/WebFetch/WebSearch/TodoWrite/Skill/ToolSearch/EnterWorktree/ExitWorktree/Monitor/TaskStop/SendMessage/Artifact/SubagentHandback）加 MCP 工具；Ctrl+B 把前台任务转后台。
  - 冷启动还注入兄弟代理名单（sibling roster）；不继承 output style 与父上下文窗口尺寸（按自身模型决定）；`cd` 不跨 Bash 调用保留；扩展思考自 v2.1.198 起继承。
  - coordinator 模式：`tools: Agent(worker, researcher), Read, Bash` 以白名单限制可再派生的代理，仅适用于 `--agent` 主线程。
  - 子代理 transcript 位于 `~/.claude/projects/{project}/{sessionId}/subagents/agent-{agentId}.jsonl`，按 cleanupPeriodDays（默认 30 天）清理。
  - 会话 fork 命令现名 `/subtask`（v2.1.212+；v2.1.161–2.1.211 为 `/fork`）。
  - agent teams 为实验特性：`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` 开启；一个会话一个团队，队友不能再派队友，lead 固定，subagent 定义中的 `skills` 字段不作用于队友。官方对比：subagent 适合“只需要结果”的任务且更省；teams 适合需要讨论协作的工作且成本更高。
- **信源**：[一手] [Subagent 配置、执行与上下文](https://code.claude.com/docs/en/sub-agents)；[一手] [命令参考](https://code.claude.com/docs/en/commands)；[一手] [CLI 参数](https://code.claude.com/docs/en/cli-reference)；[一手] [环境变量](https://code.claude.com/docs/en/env-vars)；[一手] [费用与子代理用量](https://code.claude.com/docs/en/costs)；[一手] [Skill 隔离执行](https://code.claude.com/docs/en/skills#run-skills-in-a-subagent)；[一手] [Worktree](https://code.claude.com/docs/en/worktrees)；[一手] [独立审查与验收](https://code.claude.com/docs/en/best-practices#add-an-adversarial-review-step)；[一手] [Agent teams 与 subagent 的区别](https://code.claude.com/docs/en/agent-teams#compare-with-subagents)；[一手] [自动记忆](https://code.claude.com/docs/en/memory)
- **更新**：2026-10-07（深入用法；重新核实版本规则，校正启动、恢复、权限与扫描边界）

## 2026-09-21 · 系统学习 Claude Code 与 Agent 原理的学习地图
- **问**：从宏观角度系统深入学习 Claude Code 的使用与原理，顺带学 agent 智能体工作原理，需要学哪些模块与知识点？追问：希望系统学习 Claude Code，榨干性能并成为专家，需要完整学习路线和知识点。
- **答**：沿理论底座 → 安装与单任务闭环 → 提示与验证 → 上下文／配置 → 安全与扩展 → 并行／自动化 → 量化调优学习；每阶段完成可检验的项目练习。专家能力是为任务选用合适的模型、努力档位、权限、上下文与编排方式，并以通过率、人工干预、端到端耗时、每个通过任务的 token／费用比较方案。CLAUDE.md／AGENTS.md 用于常驻项目约定，skills 按需加载，hooks 做确定性动作，MCP 接外部工具，subagent 隔离上下文；复杂或独立任务再用 worktree／并行会话，重复流程再用 `claude -p`／CI／Agent SDK。Windows 原生 Git Bash 可以运行 Claude Code，但内置 Bash 沙箱目前只支持 macOS、Linux、WSL2。
- **信源**：[一手] [Anthropic Agent 原理](https://www.anthropic.com/engineering/building-effective-agents)；[一手] [Claude Code 工作原理](https://code.claude.com/docs/en/how-claude-code-works)；[一手] [最佳实践](https://code.claude.com/docs/en/best-practices)；[一手] [扩展功能选择](https://code.claude.com/docs/en/features-overview)；[一手] [模型配置](https://code.claude.com/docs/en/model-config)；[一手] [费用管理](https://code.claude.com/docs/en/costs)；[一手] [沙箱](https://code.claude.com/docs/en/sandboxing)
- **更新**：2026-09-24（扩展为可执行路线；补充量化调优与 Windows 限制）
- **关联**：深化本文件 2026-09-21 subagent 条目——subagent 属核心机制层，是 orchestrator-workers 模式的实例；[[AI 编程#2026-09-22 · 国内外 AI Agent 编程工具概览]]；[[AI 编程#2026-10-20 · 将 WASM 封装为 MCP 供 Agent 调用的可行性与形态]]

## 2026-10-12 · Claude Code 高质量编程插件的选择与组合
- **问**：目前比较火的 Claude Code，质量比较高的编程插件有哪些？追问：对于开发者，有哪些插件或 skill 是必须装的吗？还是说装尽可能少的插件？
- **答**：优先按功能缺口选择：Superpowers 管开发流程，Context7 查版本相关文档，语言 LSP 插件提供诊断与符号导航；前端可补 Frontend Design 和 Playwright，审查可补 PR Review Toolkit。ECC（原 Everything Claude Code）是覆盖多种工程技能的社区套件，含 Spring Boot 技能；Feature Dev 是 Anthropic 的新功能开发流程；没有通用必装插件或外部 skill；建议从最小够用配置开始，先完善项目约定与可执行验证，再按反复出现的缺口增加扩展。先选一种主流程，再按项目补工具；控制启用组件、自动触发范围和上下文成本，实际质量收益尚未统一实测。
- **选型依据与限制**：
  - Superpowers 作者文档规定设计确认、计划、测试驱动开发（Test-Driven Development，TDD）、审查与完成前验证；适合多步骤开发，但确认与验证步骤会增加交互。2026-10-12 作者仓库显示约 29.8 万 stars，此数只反映关注度。
  - ECC 作者仓库显示约 27.7 万 stars，提供 skills、agents、commands 和 hooks，包含 Spring Boot 模式、安全、TDD 与验证技能。当前仓库名和原生安装名已变为 `affaan-m/ECC`、`ecc@ecc`；原生插件和完整手工安装不可重复叠加。
  - Context7 从来源文档提取版本相关说明与示例，适合库 API 与升级任务；应明确库名和版本，不能将检索结果视为测试证明。
  - 官方 LSP 插件：Java 为 `jdtls-lsp`，TypeScript／JavaScript 为 `typescript-lsp`，Python 为 `pyright-lsp`；插件不附带服务器程序，需另装并放入启动 Claude 的 shell 的 PATH。当前官方文档说明云会话不启动插件语言服务器。
  - Frontend Design 指导字体、配色、动画与界面实现；Playwright 提供浏览器操作，可用于交互验证。Microsoft 当前还提供 CLI＋Skills 路径，并说明该路径通常更节省上下文；MCP 适合持续浏览器状态与探索操作。
  - PR Review Toolkit 含 6 个专项代理，覆盖注释、测试、错误处理、类型、代码质量与简化，可以按方面选用。Feature Dev 采用 7 阶段流程，含代码探索、需求澄清、架构与审查；多代理和确认步骤使它更适合较大的功能任务。
  - 安装面板可显示常驻与调用时的上下文成本；选择前应结合任务复杂度，而非只看插件数量。
- **信源**：[一手] [Anthropic 官方插件目录](https://claude.com/marketplace/plugins)；[一手] [插件安装、范围与上下文成本](https://code.claude.com/docs/en/discover-plugins)；[一手] [Superpowers 作者仓库](https://github.com/obra/superpowers)；[一手] [ECC 作者仓库](https://github.com/affaan-m/ECC)；[一手] [Context7 作者仓库](https://github.com/upstash/context7)；[一手] [官方语言服务器插件](https://code.claude.com/docs/en/plugins/code-intelligence)；[一手] [Frontend Design 文档](https://raw.githubusercontent.com/anthropics/claude-plugins-official/main/plugins/frontend-design/README.md)；[一手] [Playwright MCP 作者仓库](https://github.com/microsoft/playwright-mcp)；[一手] [PR Review Toolkit 文档](https://raw.githubusercontent.com/anthropics/claude-plugins-official/main/plugins/pr-review-toolkit/README.md)；[一手] [Feature Dev 文档](https://raw.githubusercontent.com/anthropics/claude-plugins-official/main/plugins/feature-dev/README.md)
- **追问深化**：
  - 官方说明内置文件操作、搜索、执行与网页工具覆盖多数编程任务；应先在 CLAUDE.md 中写清项目约定和构建／测试命令，并提供可执行的验收条件，外部插件和 skill 可按具体问题再加。
  - 插件是技能、代理、hooks 和工具连接的包装，插件数量不直接等于开销。启用插件的技能／代理／命令名称与描述通常常驻上下文；默认 skill 正文调用时才进入对话，并跨后续轮次保留，不能理解为调用后立即卸载。
  - 普通会话中，skill 的 `disable-model-invocation: true` 禁止模型自行调用并移除其常驻描述，仍允许用户手动调用；第三方或共享 skill 可通过 `skillOverrides` 设置 `user-invocable-only`，无需直接改原文件。
  - 当前 MCP 工具搜索默认开启，完整工具 schema 按需加载；未调用工具仍可贡献名称及服务器指令，不能概括为所有工具全文常驻。hooks 可在模型上下文外执行，返回输出才占上下文；执行时间仍可能产生代价。
  - 推荐按重复缺口增量配置：符号定位／诊断选语言 LSP；版本文档查询选 Context7；反复重复的项目流程沉淀为窄范围 skill；需要设计、计划、测试与审查约束时再选 Superpowers 等主流程。
  - 新插件可以先选 local scope，只为本人在当前仓库启用；在 shell 中用 `claude plugin details <name>` 查看估计的常驻与调用成本，在会话中用 `/context` 查看当前工具等占用。保留标准应是减少返工且总耗时／用量可接受，不设任意“最多几个”的统一限制。
- **补充信源**：[一手] [扩展选择与加载策略](https://code.claude.com/docs/en/features-overview)；[一手] [Skill 调用控制与正文生命周期](https://code.claude.com/docs/en/skills)；[一手] [插件上下文成本测量](https://code.claude.com/docs/en/plugins/measure)；[一手] [内置工具与执行闭环](https://code.claude.com/docs/en/how-claude-code-works)；[一手] [项目约定与可执行验证](https://code.claude.com/docs/en/best-practices)
- **更新**：2026-10-12（补充必装边界、按需加载、最小够用配置与成本检查）

## 2026-10-15 · 用 Claude Code 与 Agent SDK 自建 PDF 翻译流程
- **问**：基于 Claude Code 等智能体与工具搭建自己的 PDF 翻译流程，应选哪些库与方案？
- **答**：个人交互式任务可用 Claude Code 配合专用 Skill，嵌入自有 Python 或 TypeScript 程序的批处理可用官方 Claude Agent SDK，由其提供工具调用、会话、子智能体与控制机制。translate-book 提供分块翻译、术语反馈、断点续跑和多格式输出，但采用重新排版；保留原版式需要另接 PDF 排版工具和翻译适配层，整体组合未实测。
- **信源**：[一手] [Claude Agent SDK](https://code.claude.com/docs/en/agent-sdk/overview)；[一手] [Python SDK](https://github.com/anthropics/claude-agent-sdk-python)；[一手] [Claude Code Skills](https://code.claude.com/docs/en/skills)；[一手] [translate-book](https://github.com/deusyu/translate-book)；[一手] [BabelDOC 接口说明](https://github.com/funstory-ai/BabelDOC)
- **关联**：[[机器翻译#2026-10-15 · PDF 文档翻译的成熟方案与库服务选型]]

## 2026-10-18 · 2026 年 3 月 31 日 Claude Code 源码泄露相关项目
- **问**：上次 Claude Code 源码泄露，相关开源项目；已确认指 2026 年 3 月 31 日那次。
- **答**：源码研究可看 ChinaSiro/claude-code-sourcemap（v2.1.88 的 source map 还原结果）与 sanbuphy/learn-coding-agent（原 claude-code-source-code，当前为架构研究材料）；独立实现可看 ultraworkers/claw-code（原 instructkr/claw-code，当前以 Rust 为主、MIT 许可证，作者定位为研究展品）与 Kuberwastaken/claurst（原 claude-code，Rust，仓库声明 GPL-3.0 与 Beta 状态），周边可看 Rangizingo/cc-cache-fix 的缓存补丁及检测工具。以上功能与定位依据作者文档，运行效果及与官方功能的一致性未实测；Anthropic 官方许可证仍保留全部权利，不能将泄露存档视为官方开源授权。
- **信源**：[一手] [ChinaSiro 源码还原仓库](https://github.com/ChinaSiro/claude-code-sourcemap)；[一手] [sanbuphy 架构研究仓库](https://github.com/sanbuphy/learn-coding-agent)；[一手] [Claw Code 当前仓库](https://github.com/ultraworkers/claw-code)；[一手] [Claw Code MIT 许可证](https://github.com/ultraworkers/claw-code/blob/main/LICENSE)；[一手] [Claurst 当前仓库](https://github.com/Kuberwastaken/claurst)；[一手] [Claurst 许可证](https://github.com/Kuberwastaken/claurst/blob/main/LICENSE.md)；[一手] [缓存补丁作者仓库](https://github.com/Rangizingo/cc-cache-fix)；[一手] [Anthropic 官方许可证](https://github.com/anthropics/claude-code/blob/main/LICENSE.md)

## 2026-10-18 · Claude Code 文档站源码与全部页面批量获取
- **问**：https://code.claude.com/docs/ 这个网站本身有没有源码，如何批量获取全部页面内容？
- **答**：截至 2026-10-18，未找到官方公开的完整文档站工程仓库；官方 anthropics/claude-code 仓库不包含该站的完整文档工程，公开 Markdown 导出也不等于原始源码。可直接下载 llms-full.txt 获取 228 页英文正文合集；按 llms.txt 递归读取 /_llms/ 语言索引再下载 .md，可获取索引列出的 12 种语言、2,736 页，或只选 228 页简体中文；媒体文件、布局与未列入索引的内容不在此范围。
- **核实细节**：简体中文索引路径为 /docs/_llms/zh-cn.txt（小写），其正文路径为 /docs/zh-CN/*.md。实测 sitemap.xml 仅列出 2,713 个 URL，与文档索引有差异，因此使用递归文档索引枚举；不把 sitemap 当作唯一完整性依据。PowerShell 脚本已保存至提问记录/附件/Get-ClaudeCodeDocs.ps1，支持语言选择、索引预览、重试及下载结果清单；语法与全部索引发现已验证，未执行全部正文下载。
- **信源**：[一手] [Claude Code 官方仓库](https://github.com/anthropics/claude-code)；[一手] [官方文档索引](https://code.claude.com/docs/llms.txt)；[一手] [英文正文合集](https://code.claude.com/docs/llms-full.txt)；[一手] [简体中文索引](https://code.claude.com/docs/_llms/zh-cn.txt)；[一手] [单页 Markdown 示例](https://code.claude.com/docs/zh-CN/overview.md)；[一手] [网站地图](https://code.claude.com/docs/sitemap.xml)；[一手] [Mintlify 索引、递归索引与合集规则](https://www.mintlify.com/docs/ai/llmstxt)；[一手] [Mintlify Markdown 导出规则](https://www.mintlify.com/docs/ai/markdown-export)
