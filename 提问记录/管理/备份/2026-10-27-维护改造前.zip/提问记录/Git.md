# Git

## 综述

Git 是分布式版本控制系统；Bash 是命令解释器（Shell）。Git Bash 是 Git for Windows 提供的 Bash 命令行环境，让用户在 Windows 上按类 Unix 的方式执行 Git 与配套工具。理解 Git Bash 时，应区分负责版本管理的 Git、负责解释命令的 Bash，以及将这些工具带到 Windows 的软件包。

## 2026-10-10 · Git Bash 是什么及 Git 与 Bash 的分工
- **问**：什么是 git bash？
- **答**：Git Bash 是 Git for Windows 提供的 Bash 命令行环境。Git 负责版本管理，Bash 负责解释命令；例如在仓库目录执行 `git status` 时，Bash 调用 Git，由 Git显示工作区状态。
- **信源**：[一手] [Git for Windows](https://gitforwindows.org/)；[一手] [Git 官方首页](https://git-scm.com/)；[一手] [GNU Bash：What is Bash?](https://www.gnu.org/software/bash/manual/html_node/What-is-Bash_003f.html)；[一手] [git-status 官方文档](https://git-scm.com/docs/git-status)
