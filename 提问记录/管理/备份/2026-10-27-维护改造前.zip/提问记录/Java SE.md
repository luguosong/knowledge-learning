# Java SE

## 综述

Java 标准版（Java Platform, Standard Edition，Java SE）的学习以长期支持（Long-Term Support，LTS）版 Java 开发工具包（Java Development Kit，JDK）为练习基线（原定 JDK 21；2026-10-15 修正为 JDK 25，当前 LTS，路线与知识领域不变，21→25 仅少量增量特性），按“工具与执行 → 语言和对象模型 → 泛型、异常与核心类库 → 集合与函数式处理 → 输入/输出（Input/Output，I/O）、时间、网络等平台应用程序接口（Application Programming Interface，API）→ 并发 → 类加载、模块与打包”递进。先能写出行为正确的程序，再解释类型约束、API 契约和运行机制；密码、安全、桌面、可扩展标记语言（Extensible Markup Language，XML）、本地互操作等按项目需要深入。该路线覆盖主要知识领域和核心 API 家族，不逐项枚举 Java SE 的每个类与方法；精确行为以对应版本规范和 API 文档为准。资料主线：《Java核心技术》第 13 版（2024，Java 21）与官方 dev.java、docs.oracle.com 承担系统学习（经典 Java Tutorials 已冻结在 JDK 8，比 dev.java 详细，可作免费深挖参考或预算受限时的替代主线，均按 21 版核对），《On Java 中文版》（2022，基于 Java 8）接替《Java编程思想》承担语言深读，《Effective Java》第 3 版承担最佳实践，《Java并发编程实战》承担并发专项；书籍覆盖的版本与练习基线不同时，以官方文档为准。JDK 8→25 跨 17 个版本、语言／平台／运行时三层换代，但主体知识结构（类型、对象、泛型、集合、并发语义、I/O）不变，旧资料按基线翻译语法与默认行为即可。类库宏观结构按“Java SE 标准 API（java.base 基础模块与其他领域模块）＋ JDK 专属 API”理解；模块组织包并声明依赖与导出，包组织类型，不能把包名前缀当作标准／专属／内部 API 的判据。

## 2026-09-23 · Java SE 的学习路线与完整知识点
- **问**：整理 javaSE的学习路线，以及涉及的全部知识点。
- **答**：先掌握语言、对象、泛型、异常、集合和常用 API，再学习并发、反射、模块与运行时机制；每阶段以可运行程序和机制解释验收。下文是基于 Java SE 21 规范与官方学习资料整理的学习建议，不是官方统一课程。
- **信源**：[一手] [Java SE 21 与 JDK 21 规范目录](https://docs.oracle.com/en/java/javase/21/docs/specs/)；[Java SE 21 API 文档](https://docs.oracle.com/en/java/javase/21/docs/api/index.html)；[JDK 21 工具规范](https://docs.oracle.com/en/java/javase/21/docs/specs/man/index.html)；[Dev.java 学习目录](https://dev.java/learn/)；[Java SE 21 语言特性状态](https://docs.oracle.com/en/java/javase/21/language/java-language-changes-summary.html)。核实日期：2026-09-23。
- **更新**：2026-10-15（追问练习基线选 21 还是 25，见文末修正）
- **关联**：[[Java#2026-09-22 · 成为 Java 专家的完整学习路线]]；[[Spring#2026-10-15 · JDK 25 支持现状（Spring 各线）]]

### 范围与学习顺序

以 Java 语言规范、Java SE 21 API、Java 虚拟机规范及 JDK 21 工具文档确定范围。这里的“完整”指**知识领域完整**；每个类和方法的清单以 [Java SE 21 API 文档](https://docs.oracle.com/en/java/javase/21/docs/api/index.html) 为准。先用普通 `javac`、`java` 和一个小程序理解运行路径，再逐步引入其他工具。JDK 21 是本路线的练习基线；换用其他版本时，应重新核对 API 和预览状态。

```mermaid
graph TB
    A["工具与执行"] --> B["语法、类型和控制流"]
    B --> C["类、对象和类型设计"]
    C --> D["泛型、异常和注解"]
    D --> E["核心类库、集合和 Stream"]
    E --> F["I/O、时间、网络等平台 API"]
    F --> G["并发和虚拟线程"]
    G --> H["类加载、反射、模块与打包"]
    H --> I["按项目深入安全、桌面和本地互操作"]
    P["查规范、调试和小项目练习"] -.-> B
    P -.-> E
    P -.-> H
    classDef start fill:#d3f9d8,stroke:#2f9e44,color:#111;
    classDef core fill:#e7f5ff,stroke:#1971c2,color:#111;
    classDef platform fill:#e5dbff,stroke:#5f3dc4,color:#111;
    classDef advanced fill:#ffe8cc,stroke:#d9480f,color:#111;
    classDef support fill:#f8f9fa,stroke:#868e96,color:#111;
    class A start;
    class B,C,D,E core;
    class F,G,H platform;
    class I advanced;
    class P support;
```

| 阶段 | 学习重点 | 完成标志 |
| --- | --- | --- |
| 1．工具与执行 | JDK、源文件、编译、启动、调试和文档 | 能从命令行编译、运行、打包并定位简单错误 |
| 2．语言基础 | 类型、变量、表达式、控制流、数组、方法 | 能独立完成命令行程序并解释转换与参数传递 |
| 3．对象与类型设计 | 类、接口、继承、多态、对象契约、现代类型 | 能建立小型模型并说明封装与组合的选择 |
| 4．类型约束与错误处理 | 泛型、异常、资源关闭、注解 | 能设计类型安全的 API，并正确传播异常与关闭资源 |
| 5．核心类库与数据处理 | 字符串、数字、集合、Lambda、Stream | 能选择集合并写出可读的数据处理流程 |
| 6．外部数据与平台 API | 文件、字符集、时间、网络、JDBC 等 | 能可靠读取、转换、传输和持久化数据 |
| 7．并发 | 共享状态、任务执行、取消、虚拟线程 | 能说明线程安全条件，并控制任务数量和生命周期 |
| 8．运行机制与组织 | 类加载、反射、模块、字节码、打包 | 能解释程序如何加载与运行，并诊断依赖和运行问题 |

### 1．工具、编译与执行

- **开发工具包**：版本、安装、`java` 与 `javac`；`jshell` 试验语句；集成开发环境（Integrated Development Environment，IDE）的断点、单步、调用栈和变量检查。
- **程序路径**：`.java` 源文件 → `javac` 编译 → `.class` 字节码 → `java` 启动；`main` 入口、程序参数、系统属性、环境变量、退出码；包名、目录布局、`import`、类路径（class path）。
- **开发工具**：用 `jar` 制作 Java 归档文件（Java Archive，JAR），理解清单文件；用 `javadoc` 生成文档、`javap` 查看字节码；后续再用 `jdeps`、`jlink`、`jpackage`、`jdb`、`jcmd`。具体参数查 [JDK 21 工具规范](https://docs.oracle.com/en/java/javase/21/docs/specs/man/index.html)。

### 2．语言基础与类型

- **源码结构**：标识符、关键字、字面量、注释、声明、表达式、语句、代码块与作用域。
- **类型与值**：八种基本类型、引用类型、`null`、变量的初始化与确定赋值、`final`、局部变量类型推断 `var`；数值提升、宽化与窄化转换、溢出、装箱与拆箱。
- **运算与流程**：算术、比较、逻辑、位运算、移位、条件运算符及优先级；`if`、`switch` 语句与表达式、`for`、增强 `for`、`while`、`do-while`、`break`、`continue`、`return`、`assert`。
- **数组与方法**：一维和多维数组、数组边界、方法声明与调用、重载、返回值、递归、可变参数；Java 参数传递的是**值**，对象参数传递的是引用值。
- **文本基础**：`String` 不可变性、`StringBuilder`、字符串比较；`char` 是 UTF-16 代码单元，处理完整 Unicode 字符时应认识代码点与代理对。基础语法以 [语言基础教程](https://dev.java/learn/language-basics/) 和语言规范核对。

### 3．对象模型与现代语言特性

- **类与对象**：字段、方法、构造器、初始化顺序、实例成员与 `static` 成员、`this`、`super`、包和四级访问控制。
- **面向对象**：封装、继承、多态、抽象类、接口与默认方法；重载、重写、方法隐藏、动态分派、`final`；组合与继承的适用条件。
- **类的形态**：静态嵌套类、内部类、局部类、匿名类、枚举（`enum`）；记录类（`record`）、密封类（`sealed`）、`instanceof` 模式、`switch` 模式和记录模式。
- **对象契约**：对象身份与逻辑相等；`Object.equals`、`hashCode`、`toString`；`Comparable`、`Comparator`；可变性、不可变性与防御性复制。类与对象的基础见 [官方教程](https://dev.java/learn/classes-objects/)。

### 4．泛型、异常、资源与注解

- **泛型（Generics）**：泛型类、接口、方法和构造器；上界、通配符、协变读与逆变写、不变性、类型推断；原始类型、类型擦除、桥接方法、可具体化类型、泛型数组限制、堆污染与泛型可变参数。
- **异常（Exception）**：`Throwable`、`Error`、受检异常与非受检异常；`throw`、`throws`、`try`、`catch`、`finally`、多重捕获、异常链与受抑制异常；自定义异常和异常边界。文件等资源用 `AutoCloseable` 与 `try-with-resources` 管理。[异常教程](https://dev.java/learn/exceptions/)说明语言要求。
- **注解（Annotation）**：`@Override`、`@Deprecated` 等内置注解；自定义 `@interface`、元素、`@Target`、`@Retention`、`@Repeatable`、`@Inherited`；源码、类文件与运行时保留策略；反射读取、编译期注解处理器和生成代码。注解本身不自动执行逻辑。[注解教程](https://dev.java/learn/annotations/)给出用途与限制。

### 5．核心类型、集合与函数式处理

- **常用类型**：`Object`、`Objects`、包装类、`Math`、`BigInteger`、`BigDecimal`、`UUID`、`Optional`、`Arrays`、`Collections`、`RandomGenerator`、`Base64`；区分数值、文本和对象的比较语义。
- **集合框架（Collections Framework）**：`Iterable`、`Iterator`、`Collection`、`List`、`Set`、`Queue`、`Deque`、`Map`；`SortedSet`、`NavigableSet`、`SortedMap`、`NavigableMap`；JDK 21 的 `SequencedCollection`、`SequencedSet`、`SequencedMap`。
- **常用实现与选择**：`ArrayList`、`LinkedList`、`ArrayDeque`、`PriorityQueue`、`HashSet`、`LinkedHashSet`、`TreeSet`、`HashMap`、`LinkedHashMap`、`TreeMap`、`EnumSet`、`EnumMap`；遍历、排序、查找、散列、顺序、复杂度、键的相等契约；可修改集合、不可修改视图和不可变元素分别判断。[集合教程](https://dev.java/learn/api/collections-framework/)与 [JDK 21 顺序集合说明](https://docs.oracle.com/en/java/javase/21/core/creating-sequenced-collections-sets-and-maps.html)是核对依据。
- **函数式处理**：函数式接口、`java.util.function`、Lambda、方法引用、变量捕获；`Stream` 的数据源、中间操作、终止操作与惰性执行；`map`、`filter`、`flatMap`、`reduce`、`collect`、`Collector`、基本类型流、`Optional`、并行流与副作用。[Stream 教程](https://dev.java/learn/api/streams/)按这些主题展开。

### 6．文本、时间、文件与外部系统

- **文本和国际化**：Unicode 代码点、UTF-8 等字符集、编码与解码、`Charset`；正则表达式 `Pattern` / `Matcher`；`Locale`、`ResourceBundle`、数字与日期格式化。
- **日期时间**：`Instant`、`LocalDate`、`LocalTime`、`LocalDateTime`、`OffsetDateTime`、`ZonedDateTime`、`ZoneId`；时间点与本地日期时间的区别、时区规则、`Duration`、`Period`、解析与格式化；旧版 `Date` / `Calendar` 的互操作。[日期时间教程](https://dev.java/learn/date-time/)按类型逐项讲解。
- **输入/输出（Input/Output，I/O）**：字节流与字符流、缓冲、标准输入输出、`Path` 与 `Files`、目录和元数据；`ByteBuffer`、`Channel`、`Selector`，阻塞与非阻塞 I/O；对象序列化的格式、兼容性与反序列化风险。日常文件操作先掌握 `Path` / `Files`。[I/O 教程](https://dev.java/learn/java-io/)提供学习顺序。
- **网络与 HTTP**：`URI`、`InetAddress`、`Socket`、`ServerSocket`、`DatagramSocket`、`HttpClient`、WebSocket 客户端；请求与响应、连接、超时、字符集和传输层安全协议（Transport Layer Security，TLS）的 API 使用。
- **数据库与其他平台接口**：Java 数据库连接（Java Database Connectivity，JDBC）的 `DataSource`、`Connection`、`PreparedStatement`、`ResultSet`、事务与资源关闭；`java.util.logging`；`java.xml` 的 DOM、SAX、StAX 与 JAXP。按实际项目选择深度，先会查对应模块的 API 文档。

### 7．并发与线程模型

- **基本语义**：`Thread`、`Runnable`、`Callable`；线程状态、启动与结束、`join`、中断、取消、超时；共享状态、竞态、死锁、活锁和饥饿。
- **正确性**：`synchronized`、`volatile`、`wait` / `notify`；Java 内存模型（Java Memory Model，JMM）的可见性、原子性、有序性与 happens-before；安全发布、不可变对象、`final` 字段语义。
- **并发工具**：`Lock` / `Condition`、原子类与比较并交换（Compare-and-Set，CAS）、`VarHandle`、`ExecutorService` 与线程池、任务队列和拒绝策略、`Future`、`CompletableFuture`、`ForkJoinPool`；`ConcurrentHashMap`、并发队列、`Semaphore`、`CountDownLatch`、`ThreadLocal`；深入时再读 `LockSupport`、`AbstractQueuedSynchronizer` 与 `Flow` 的发布订阅和背压。
- **虚拟线程（Virtual Thread）**：JDK 21 正式提供；掌握任务生命周期、中断、阻塞 I/O、资源上限和线程局部变量的成本。虚拟线程适合大量等待 I/O 的任务，不能提高 CPU 密集计算的吞吐能力。[JEP 444](https://openjdk.org/jeps/444)给出边界。

### 8．类加载、反射、模块与 JVM 基础

- **运行机制**：class 文件、字节码、验证、类加载、链接、初始化、类加载器与类身份；虚拟机栈、堆、垃圾回收的基本职责；规范规定的语义与 HotSpot 实现细节分开学习。深入 GC、JIT 和诊断接续 [[Java#2026-09-23 · JVM 的系统学习路线与知识地图]]。
- **反射与动态调用**：`Class`、`Field`、`Method`、`Constructor`、动态代理、`InvocationHandler`、`MethodHandle`；访问控制、模块开放、反射的适用边界。[反射教程](https://dev.java/learn/reflection/)建议在语言基础之后学习。
- **代码组织**：包、JAR、类路径、模块路径、Java 平台模块系统（Java Platform Module System，JPMS）；`module-info.java` 的 `requires`、`exports`、`opens`、`uses`、`provides`；`ServiceLoader` 与服务提供者接口（Service Provider Interface，SPI）。用 `jdeps` 查依赖、`jlink` 定制运行时、`jpackage` 打包应用。[模块教程](https://dev.java/learn/modules/)讲清了类路径与模块路径的关系。

### 9．按应用需要深入的 Java SE / JDK API

- **安全与密码**：`java.security`、`javax.crypto`、证书 API、`KeyStore`、`SecureRandom`、`MessageDigest`、`Mac`、`Signature`、`Cipher`、安全提供者与 TLS；按需查 `java.security.jgss`、`java.security.sasl`、`java.smartcardio`、`java.xml.crypto`。先掌握算法、密钥和参数的协议要求，再查具体 API 契约。
- **桌面与系统集成**：`java.desktop` 的 AWT / Swing、JavaBeans、音频、图像、打印与无障碍接口；`java.datatransfer` 的数据传输；`java.management` 的 Java 管理扩展（Java Management Extensions，JMX）与 `java.management.rmi`；`java.instrument` 代理；`java.naming` 的 JNDI、`java.rmi`、`java.prefs`。按使用场景选学。
- **其他 Java SE 模块**：`java.compiler` 的语言模型、编译器与注解处理接口；`java.scripting` 脚本接口；`java.sql.rowset`、`java.transaction.xa` 的数据库扩展；`java.se` 聚合模块。模块清单及边界以 [Java SE 21 API 概览](https://docs.oracle.com/en/java/javase/21/docs/api/index.html) 为准。
- **本地互操作**：Java 本地接口（Java Native Interface，JNI）和外部函数与内存 API（Foreign Function and Memory API，FFM）。FFM 在 JDK 21 属[预览 API](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/foreign/package-summary.html)，使用前核对版本文档；普通 Java SE 学习可放在最后。

### JDK 21 版本节点与验收

- **正式特性**：`record`、密封类、文本块和 `switch` 表达式已在早期版本转正；JDK 21 的记录模式与 `switch` 模式匹配是正式语言特性，顺序集合与虚拟线程也在 JDK 21 正式提供。**预览特性**：例如 JDK 21 的字符串模板、未命名模式与变量、未命名类和实例 `main` 方法；不要把预览语法当成跨版本稳定基础。[语言状态表](https://docs.oracle.com/en/java/javase/21/language/java-language-changes-summary.html)、[顺序集合说明](https://docs.oracle.com/en/java/javase/21/core/creating-sequenced-collections-sets-and-maps.html)、[JEP 444](https://openjdk.org/jeps/444)分别支持这些判断。
- **练习链**：命令行小程序 → 带 `record` / 接口 / 泛型的领域模型 → 集合与 Stream 数据汇总 → 带字符集和时区处理的文件工具 → 有超时与取消的并发任务 → JAR / 模块打包并用 `javap`、`jdeps` 检查。
- **总验收**：能解释类型转换、相等契约、集合选择、泛型边界、异常传播、资源关闭、时间语义、线程安全和类加载；能用 JDK 21 官方 API 文档确认未记住的具体行为。

### 修正：练习基线选 21 还是 25（2026-10-15 追问）

- **旧结论（保留）**：JDK 21 是本路线的练习基线（2026-09-23）。
- **新结论**：新学习者直接以 **JDK 25** 为练习基线。JDK 25 于 2025-09-16 GA，是当前 LTS（OpenJDK 项目页原文："JDK 25 will be a long-term support (LTS) release from most vendors"）；JDK 27 于 2026-09-15 GA 但未被标注为 LTS，按 17→21→25 的两年 LTS 节奏，25 仍是当前 LTS。路线八个阶段与知识领域不变，只把"按 21 版文档核对"替换为"按 25 版文档核对"。
- **已核实的 JDK 25 增量（与学习者相关）**：转正——模块导入声明（JEP 511）、紧凑源文件与实例 main 方法（JEP 512；21 中为预览、本路线曾提示勿作稳定基础，25 起可正常使用）、灵活构造器体（JEP 513）、Scoped Values（JEP 506）；仍为预览——结构化并发（JEP 505，第五轮）、原始类型模式匹配（JEP 507，第三轮）、Stable Values（JEP 502），预览特性仍不作稳定基础。VM 层另有紧凑对象头（JEP 519）与 AOT 类加载（JEP 514／515）等性能项，不影响语言学习。
- **教材不换**：Core Java 13（Java 21）、On Java（Java 8）等在 25 上直接编译运行；语言与平台主体（类型、对象模型、泛型、集合、Stream、并发基础、IO、模块）两个 LTS 间完全一致。
- **信源**：[一手] [JDK 25 项目页（GA 2025-09-16，LTS）](https://openjdk.org/projects/jdk/25/)；[JDK 27 项目页（GA 2026-09-15，未标注 LTS）](https://openjdk.org/projects/jdk/27/)；[JEP 索引（JDK 25 JEP 清单与状态）](https://openjdk.org/jeps/0)。核实日期：2026-10-15。

## 2026-10-14 · Java SE 经典学习书籍与网站
- **问**：Java SE 有哪些经典学习书籍和网站？
- **答**：书籍主线为《Java核心技术》第 13 版（2024，覆盖 Java 21）作系统教程、《On Java 中文版》（2022，基于 Java 8）接替已过时的《Java编程思想》、《Effective Java》第 3 版（2018，覆盖至 Java 9）作最佳实践、《Java并发编程实战》（2006）作并发专项；网站以 Oracle 官方 dev.java 与 docs.oracle.com 为准，Baeldung、Jenkov、廖雪峰教程作补充。Java 每半年发版、书按 LTS 更新，选书先比对覆盖版本与练习基线的差距，行为争议以官方文档仲裁。追问核实：经典 Java Tutorials（docs.oracle.com/javase/tutorial）确实比 dev.java/learn 详细——老教程每页声明内容针对 JDK 8 且部分技术已不可用，并指向 dev.java 作更新版；两者分工见正文末节。再问老教程与《Java核心技术》怎么选：决策变量是版本代际、成本与语言而非详细度，默认《Java核心技术》第 13 版作主线、老教程作免费深挖参考。
- **信源**：[一手] [Core Java 第 13 版付印公告（Horstmann 博客）](https://horstmann.com/unblog/2024-06-22/index.html)；[jcip.net（JCIP 官网）](https://jcip.net)；[Dev.java 学习目录](https://dev.java/learn/)；[Jenkov Java 教程索引](https://jenkov.com/tutorials/java/index.html)；[廖雪峰 Java 教程](https://liaoxuefeng.com/books/java/index.html)；[TIJ4 官方示例代码仓库（作者 GitHub）](https://github.com/BruceEckel/TIJ4-code)；[Head First Java 第 3 版目录页（O'Reilly）](https://www.oreilly.com/library/view/head-first-java/9781492091646)；[The Java Tutorials 首页（含 JDK 8 声明原文）](https://docs.oracle.com/javase/tutorial/index.html)。二手（书目信息）：[On Java 中文版基础卷（百度百科）](https://baike.baidu.com/item/On%20Java%20%E4%B8%AD%E6%96%87%E7%89%88%E5%9F%BA%E7%A1%80%E5%8D%B7/61439301)；[On Java 中文版基础卷（豆瓣）](https://m.douban.com/book/subject/35751619/reviews)。核实日期：2026-10-14。
- **更新**：2026-10-14
- **关联**：[[Java SE#2026-09-23 · Java SE 的学习路线与完整知识点]]

### 书籍清单与取舍

| 书 | 版本／年份 | 覆盖 Java | 定位与取舍 |
| --- | --- | --- | --- |
| 《Java核心技术》（Core Java）卷 I／II | 第 13 版，2024 | Java 21 | 系统主教程，与 JDK 21 练习基线一致；中文版历史版次由机械工业出版社出版，第 13 版中文版截至 2026-10-14 未出版（英文第 13 版有售，中文最新为第 12 版 2022-05、Java 17） |
| 《Head First Java》 | 第 3 版，2022 | Java 8–17 | 零基础入门，图解风格；深度不足，作第一本而非唯一一本 |
| 《On Java 中文版》基础卷／进阶卷 | 2022（人民邮电出版社，ISBN 978-7-115-58501-1） | Java 8 | 《Java编程思想》的接替者，重讲"为什么"；基于 Java 8，Lambda 之后的新语法不在书中 |
| 《Java编程思想》（Thinking in Java） | 第 4 版，2006 | Java 5／6 | 经典但语法层已过时，不建议再作入门；思想性内容已并入 On Java |
| 《Effective Java》 | 第 3 版，2018 | 至 Java 9 | 最佳实践；record、密封类、虚拟线程等新特性需自行取舍，截至 2026-10-14 未见第 4 版官方出版信息 |
| 《Java并发编程实战》（JCIP） | 2006 | Java 5／6 | 并发正确性与 JMM 仍权威；虚拟线程不在书中，需补 dev.java 与 JEP 444 |

### 网站清单

- **dev.java/learn**：Oracle 官方学习站，按"入门 → 语言 → API → 模块 → JVM"组织路径；新特性与工具链首选，与经典 Java Tutorials 的分工见下节（一手，本次核实仍在线）。
- **The Java Tutorials**（docs.oracle.com/javase/tutorial/）：Sun 时代起积累的经典官方教程，内容冻结在 JDK 8，深度大；概念深读可用，行为按 21 版核对（一手）。
- **docs.oracle.com**：Java SE 21 API、语言规范、JVM 规范、工具规范，行为争议的最终依据（链接见 2026-09-23 条目）。
- **Baeldung**（baeldung.com）：英文实战教程库，Eugen Paraschiv 创立、团队维护，Spring 生态内容占比高（第三方，二手）。
- **Jenkov**（jenkov.com/tutorials/java/）：Jakob Jenkov 维护的简洁参考教程，含 Java 7–25 特性摘要，2026-01 仍在更新（一手）。
- **廖雪峰 Java 教程**（liaoxuefeng.com/books/java/）：中文零基础免费教程；后半延伸到 JavaEE 与 Spring，超出 Java SE 范围（一手）。

### 追问：dev.java 与经典 Java Tutorials 的分工（2026-10-14）

- **观察属实**：老教程比 dev.java/learn 详细。老教程每页顶部固定声明："The Java Tutorials have been written for JDK 8. Examples and practices described in this page don't take advantage of improvements introduced in later releases and might use technology no longer available. See Dev.java for updated tutorials taking advantage of the latest releases."——内容按 JDK 8 编写、部分技术已不可用、更新版指向 dev.java。无"已废弃"横幅，但事实冻结在 JDK 8。
- **原因**：两者是两代产品。老教程按"trail（学习路径）"组织（Learning the Java Language、Essential Classes、Collections、Date-Time、Concurrency、Generics、JDBC、国际化、反射、安全、Swing／2D 等），从 Sun 时代积累约 20 年，基础部分成书为 The Java Tutorial 第 6 版（Java 8）；dev.java 是 Oracle 约 2022–2023 年上线的重建站（Java 21 发布新闻稿称其教程由 Oracle Java 团队编写），逐主题补齐、覆盖不均：虚拟线程、record、switch 模式、模块、jshell 等新特性只有它讲，集合、并发、泛型等经典主题多数尚浅于老教程。
- **用法**：成熟概念深读读老教程，但 API 与行为一律按 Java SE 21 文档核对；老教程中已死或已移出 JDK 的内容（Applet 与部署、扩展机制 JDK 9 移除、JAXB JDK 11 起移出）直接跳过；新特性与工具链看 dev.java 与 JEP。

### 追问：经典 Java Tutorials 与《Java核心技术》怎么选（2026-10-14）

- **决策变量不是详细度**（两者同为书级篇幅、成体系），而是**版本代际、成本、语言**：老教程免费、官方、冻结在 JDK 8；《Java核心技术》第 13 版付费、覆盖 Java 21、与练习基线一致，但中文版尚未出版（英文第 13 版有售，中文最新为第 12 版、Java 17，机械工业出版社 2022-05）。
- **默认推荐**：《Java核心技术》第 13 版作主线（读英文，或以第 12 版中文配合把练习基线换到 17）；理由是整条学习路线、验收与练习链挂在 JDK 21，书与基线同版本省去逐主题"8 → 21 换算"。老教程作免费的第二参考，在泛型、并发、国际化等主题比书更细时深挖。
- **预算敏感替代**：老教程当主线 + dev.java 补新特性 + 21 版 API 文档仲裁，也可走通；代价是版本换算成本，且 `var`、`record`、密封类、switch 模式、虚拟线程等 Java 8 之后的系统讲解完全缺失（恰为路线第 3／5／7 阶段核心）。
- **信源**：[一手] [Core Java 第 13 版（O'Reilly Learning 电子版收录页）](https://learning.oreilly.com/library/view/core-java-volume/9780135371671)；二手（在售书目）：[京东《Java核心技术卷I》第 13 版英文版页](https://www.jd.com/hprm/17134fd314da8236f1a6.html)、[《JAVA核心技术：基础知识》百度百科（第 12 版中文，2022-05）](https://baike.baidu.com/item/JAVA%E6%A0%B8%E5%BF%83%E6%8A%80%E6%9C%AF%EF%BC%9A%E5%9F%BA%E7%A1%80%E7%9F%A5%E8%AF%86/15269293)。核实日期：2026-10-14。
- 2026-10-15 补：练习基线改为 JDK 25 后，Core Java 13（Java 21）与基线差一个 LTS、增量小，"书作主线"的推荐不变；行为核对改用 25 版官方文档。

## 2026-10-15 · JDK 8 与 JDK 25 差别有多大
- **问**：总结 JDK 25 和 JDK 8 差别有多大。
- **答**：跨 11 年、17 个版本，三层换代：语言写法（var、record、密封类、模式匹配、文本块、模块导入、实例 main）、平台结构与默认行为（模块系统与强封装、移出 EE／CORBA／Nashorn／CMS、UTF-8 默认字符集、标准 HttpClient）、运行时（G1 起步到新一代 GC、虚拟线程、Scoped Values、紧凑对象头与 AOT）。向后兼容成立：8 的代码大多可在 25 编译运行；主体知识结构不变，但 8 基线资料需按 25 翻译语法与默认行为。
- **信源**：[一手] [JDK 8 项目页（GA 2014-03-18，Project Lambda）](https://openjdk.org/projects/jdk8/)；[Java 语言特性演进表（Oracle，JDK 9–21）](https://docs.oracle.com/en/java/javase/21/language/java-language-changes-summary.html)；[JEP 索引（JEP 与版本归属）](https://openjdk.org/jeps/0)；[JDK 25 项目页（LTS）](https://openjdk.org/projects/jdk/25/)。核实日期：2026-10-15。
- **关联**：[[Java SE#2026-09-23 · Java SE 的学习路线与完整知识点]]

### 演化时间线

```mermaid
timeline
    title Java SE 演化：JDK 8 到 JDK 25（2014–2025）
    2014 · JDK 8 : Lambda 与 Stream : 默认方法 : java.time
    2017 · JDK 9 : 模块系统 JPMS : jshell : G1 成为默认 GC
    2018 · JDK 10–11 : var : 标准 HttpClient : 单文件直接运行 : 移出 Java EE 与 CORBA 模块
    2020 · JDK 14–15 : switch 表达式 : 文本块 : 移除 CMS 与 Nashorn
    2021 · JDK 16–17 : record 与 instanceof 模式 : 密封类 : 内部 API 默认强封装
    2022 · JDK 18 : UTF-8 成为默认字符集
    2023 · JDK 21 : 虚拟线程 : switch 模式与记录模式
    2025 · JDK 25 : Scoped Values : 模块导入与实例 main : 紧凑对象头与 AOT
```

### 三层对照

| 层 | JDK 8（2014） | JDK 25（2025） |
| --- | --- | --- |
| 语言 | Lambda／Stream 刚引入（Project Lambda 是 8 的核心特性） | var（10）、switch 表达式（14）、文本块（15）、record（16）、instanceof 模式（16）、密封类（17）、switch／记录模式（21）、模块导入与实例 main（25） |
| 平台与 API | 类路径世界；EE 模块（JAXB 等）内置；平台默认字符集；HttpURLConnection | 模块系统（9，JEP 261）与内部 API 默认强封装（16／17，JEP 396／403）；EE／CORBA 移出（11，JEP 320）；UTF-8 默认字符集（18，JEP 400）；标准 HttpClient（11，JEP 321）；SecurityManager 弃用（17，JEP 411） |
| 运行时 | Parallel GC 默认；永久代刚改为元空间 | G1 默认（9 起，JEP 248）；CMS 移除（14，JEP 363）、Nashorn 移除（15，JEP 372）；虚拟线程（21，JEP 444）；Scoped Values（25，JEP 506）；紧凑对象头（25，JEP 519）与 AOT 缓存（25，JEP 514／515） |
| 工具链 | javac／java／jar | 加 jshell（9，JEP 222）、单文件源码直接运行（11，JEP 330）、jlink（9）与 jpackage（16） |

### 8 基线资料的翻译清单

1. **语法糖重写**：示例用 var、record、switch 表达式、文本块、instanceof／switch 模式改写，行为不变、表达更短。
2. **默认行为**：字符集——8 按平台默认（中文 Windows 即 GBK，读文件经典乱码源），18 起默认 UTF-8；反射访问 JDK 内部 API——17 起默认拒绝。
3. **已移出／移除**：JAXB／JAX-WS（11 起独立库）、CORBA（11）、Nashorn（15）、CMS GC（14）——8 资料相关章节作废；SecurityManager（17 起弃用）不再新学。
4. **网络示例**：HttpURLConnection 换 HttpClient（11）。
5. **并发补充**：Thread-per-request 思路在 21 起可用虚拟线程；ThreadLocal 部分场景可换 Scoped Values（25）。

## 2026-10-15 · JDK 自身类库体系的宏观概览
- **问**：JDK自身的类库体系总结，宏观概览。
- **答**：以 JDK 25 为基线，公开类库分为 Java SE 标准 API（模块名以 java 开头）和 JDK 专属 API（模块名以 jdk 开头）；前者以 java.base 为基础，再由其他模块提供数据库、文档、桌面、管理等能力。理解时先按职责定位，再按“模块 → 包 → 类／接口”查找；下列职责分组是教学归纳，不是官方固定分层。
- **信源**：[一手] [Java SE 25 与 JDK 25 API 总览](https://docs.oracle.com/en/java/javase/25/docs/api/index.html)；[java.base](https://docs.oracle.com/en/java/javase/25/docs/api/java.base/module-summary.html)；[模块描述与依赖](https://docs.oracle.com/en/java/javase/25/docs/api/java.base/java/lang/module/ModuleDescriptor.html)；[java.net.http](https://docs.oracle.com/en/java/javase/25/docs/api/java.net.http/module-summary.html)；[java.sql 包与驱动框架](https://docs.oracle.com/en/java/javase/25/docs/api/java.sql/java/sql/package-summary.html)；[java.desktop](https://docs.oracle.com/en/java/javase/25/docs/api/java.desktop/module-summary.html)；[java.compiler](https://docs.oracle.com/en/java/javase/25/docs/api/java.compiler/module-summary.html)；[java.logging](https://docs.oracle.com/en/java/javase/25/docs/api/java.logging/module-summary.html)；[jdk.jfr](https://docs.oracle.com/en/java/javase/25/docs/api/jdk.jfr/module-summary.html)；[jdk.httpserver](https://docs.oracle.com/en/java/javase/25/docs/api/jdk.httpserver/module-summary.html)。核实日期：2026-10-15。
- **关联**：[[Java SE#2026-09-23 · Java SE 的学习路线与完整知识点]]；[[Java SE#2026-10-15 · JDK 8 与 JDK 25 差别有多大]]

### 职责地图与组织边界

- **java.base 内的基础能力**：语言与对象支持（java.lang）、集合与函数式处理（java.util、java.util.function、java.util.stream）、数值／文本／时间（java.math、java.text、java.time）、并发（java.util.concurrent）、文件与基础网络（java.io、java.nio、java.net）、安全与密码（java.security、javax.crypto、javax.net.ssl）；反射、方法句柄、外部函数与内存、class 文件处理也在该模块中。
- **其他 Java SE 模块**：java.net.http 提供网络请求客户端；java.sql 与 java.sql.rowset 提供数据库访问 API；java.naming、java.rmi、java.prefs 提供命名、远程调用与偏好设置；java.xml 与 java.xml.crypto 处理 XML 及其密码操作；java.desktop 与 java.datatransfer 提供桌面和多媒体能力；java.logging、java.management、java.management.rmi、java.instrument 提供日志、管理与程序插桩；java.compiler 与 java.scripting 提供编译与脚本接口。
- **JDK 专属公开 API**：jdk.compiler、jdk.jshell 用于开发工具集成，jdk.jfr 用于运行事件录制与消费，jdk.attach 用于附加目标虚拟机，jdk.httpserver 提供面向简单用途的服务端 API。工具模块可以包含命令行工具实现，命令本身与可调用 API 应分开理解。
- **模块与包**：java.base → java.util → List／ArrayList；java.logging → java.util.logging → Logger。模块声明依赖与对外导出；包提供类型命名和组织。除 java.base 自身外，命名模块依赖 java.base。
- **边界**：javax.crypto、javax.sql、javax.swing 均属于 Java SE，javax 不等于第三方或废弃；jdk.jfr 是公开 API，jdk 不等于内部实现；JDBC 提供标准访问 API 与驱动框架，连接具体数据库通常另加对应驱动。
