# Java

## 综述

Java 专家成长路线以语言和标准库为起点，将算法、操作系统、并发与虚拟机原理连接到服务端工程、数据一致性、性能诊断和安全交付。学习顺序建议为：Java SE 与工程基本功 → 可测试的单体服务 → 并发、JVM 与性能分析 → 缓存、消息和分布式系统 → 选择一个专项持续深入；测试、安全、文档和源码阅读贯穿全过程。专家能力以实现、解释机制、诊断故障和论证取舍衡量。当前先形成完整知识地图，尚未根据个人薄弱项与每周学习时间制定日程。Java SE 的详细路线与核心知识点已拆分至 [[Java SE#综述]]。数据结构与算法领域已将原算法概览展开为分阶段路线，并对应 Java 集合、缓存与存储结构；原有条目仅表示知识点列入路线，不表示已掌握。日志工程现已单独展开：沿“事件 → API → 实现 → 输出 → 采集与检索”学习，贯穿正确记录、上下文关联、容量与安全；区分应用日志、审计日志和 JVM 统一日志。JVM 专项沿“字节码与类 → 运行时与内存 → GC、编译与并发 → 诊断与调优”展开；先按规范理解语义，再按 JDK 版本研究 HotSpot 实现，以可复现故障和证据验收。企业平台主线已澄清：Java EE（2017 年由 Oracle 移交 Eclipse 基金会，后更名 Jakarta EE）是规范集合，Tomcat 是实现其 Web 层子集（Servlet、JSP、EL、WebSocket）的 Servlet 容器；Web 开发的事实标准由 Tomcat 与 Spring 承担，完整 Java EE 应用服务器不是学习主线。

## 2026-09-22 · 成为 Java 专家的完整学习路线
- **问**：我如果希望成为 Java 领域的专家，学习路线是怎么样的？需要学习哪些领域，每个领域需要学习哪些知识点，例如 Java SE 的集合、反射、注解等？追问：整理 javaSE的学习路线，以及涉及的全部知识点。
- **答**：建议覆盖下列 18 个主干领域，并在运行时与性能、框架与基础设施、分布式系统或安全等方向选择一个专项深入。按“会实现 → 能解释原理 → 能诊断故障 → 能论证取舍”逐步验收；以下领域划分、顺序和验收要求是基于一手资料的学习建议，不是官方统一认证标准。
- **信源**：[一手] [Dev.java 学习目录](https://dev.java/learn/)；[Java 语言与虚拟机规范](https://docs.oracle.com/javase/specs/)；[Spring Framework](https://docs.spring.io/spring-framework/reference/overview.html)；[PostgreSQL 文档](https://www.postgresql.org/docs/current/index.html)；各领域的补充一手资料见下文。核实日期：2026-09-22。
- **更新**：2026-09-23（将 Java SE 细化路线拆分为专题）
- **关联**：[[身份认证#2026-09-21 · Cookie/Session/JWT 算不算认证技术]]；[[容器编排#2026-09-21 · k8s 和 Docker 的关系（承接上条）]]；[[数据结构与算法#2026-09-22 · 数据结构与算法的完整学习路线及已有知识点对应]]；[[Java SE#2026-09-23 · Java SE 的学习路线与完整知识点]]；[[Spring#2026-09-23 · Spring 框架的完整学习路径与知识地图]]

### 使用方式与学习顺序

通用主干适用于各类 Java 开发；服务端部分结合当前 Java、Spring Boot / Cloud 工作背景展开。标记含义：A＝先掌握，B＝完成单体服务后深入，C＝按专项选学。A 与 B 是阶段，不代表能力上限。练习可以沿用当前 JDK 21，再用 JDK 25 对照版本差异；语言特性、API、预览状态和框架兼容性均以对应版本文档为准。

```mermaid
flowchart TB
    A["Java SE、算法与工程基础"] --> B["网络、数据库与 Spring 单体服务"]
    B --> C["并发、JVM 与性能诊断"]
    C --> D["缓存、消息与分布式系统"]
    D --> E["选择专项、解决复杂问题、沉淀成果"]
    F["测试、安全、文档与源码阅读"] -.-> A
    F -.-> B
    F -.-> C
    F -.-> D
    F -.-> E
    classDef basic fill:#d3f9d8,stroke:#2f9e44,color:#111;
    classDef engineering fill:#e5dbff,stroke:#5f3dc4,color:#111;
    classDef practice fill:#ffe8cc,stroke:#d9480f,color:#111;
    classDef expert fill:#c5f6fa,stroke:#0c8599,color:#111;
    classDef support fill:#e7f5ff,stroke:#1971c2,color:#111;
    class A basic;
    class B,C engineering;
    class D practice;
    class E expert;
    class F support;
```

### 1．Java SE：语言与标准库（A，机制向 B 深入）

Java 标准版（Java Platform, Standard Edition，Java SE）是后续 Java 工程学习的基础。其独立路线、分阶段验收与知识点清单见 [[Java SE#2026-09-23 · Java SE 的学习路线与完整知识点]]。本总路线在后文继续展开并发与 JVM 专项。

### 2—5．计算机基础与 Java 运行机制

| 领域与阶段 | 知识点 | 验收目标 |
| --- | --- | --- |
| 2．数据结构与算法（A → B） | 时间与空间复杂度；摊还分析；数组、链表、栈、队列、哈希表、堆、树、图；二分、排序、递归、遍历、分治、贪心、动态规划；进一步理解红黑树、B+ 树、跳表、布隆过滤器 | 根据数据规模、访问方式和内存预算选结构；解释集合与数据库索引为何这样设计 |
| 3．操作系统与硬件基础（A → B） | 进程、线程、调度、上下文切换；用户态与内核态；虚拟内存、分页、文件系统、页缓存；文件描述符、系统调用；CPU 缓存、局部性、原子指令、缓存行与伪共享 | 区分计算、内存、磁盘与网络瓶颈；解释线程增加后性能可能下降的原因 |
| 4．并发编程（A 基础，B 深入） | 线程状态；中断、取消、超时；synchronized、volatile、wait/notify、Lock、Condition；Java 内存模型（Java Memory Model，JMM）、happens-before、安全发布；比较并交换（Compare-and-Set，CAS）、原子类；线程池、队列、拒绝策略；Future、CompletableFuture、ForkJoinPool；ConcurrentHashMap；Semaphore、CountDownLatch；ThreadLocal；死锁、饥饿；虚拟线程；抽象队列同步器（AbstractQueuedSynchronizer，AQS）源码 | 实现有界并发任务处理；证明共享状态的正确性；模拟超时、取消、拒绝和死锁并定位原因 |
| 5．Java 虚拟机（B） | Java 虚拟机（Java Virtual Machine，JVM）规范与 HotSpot 实现的区别；class 文件、字节码；类加载、链接、初始化与类加载器；栈、堆、方法区与 HotSpot 元空间；对象分配与引用类型；垃圾回收（Garbage Collection，GC）、可达性、安全点；G1、ZGC；即时编译（Just-In-Time Compilation，JIT）、内联、逃逸分析、反优化；直接内存、类卸载、内存泄漏 | 从线程转储、堆转储、GC 日志和性能记录分析内存不足、锁竞争与延迟问题；明确结论适用的 JDK 与实现 |

依据：[一手] [MIT 算法课程](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/)、[OSTEP 原作者教材](https://pages.cs.wisc.edu/~remzi/OSTEP/)、[并发 API](https://docs.oracle.com/en/java/javase/25/docs/api/java.base/java/util/concurrent/package-summary.html)、[JLS 线程与锁](https://docs.oracle.com/javase/specs/jls/se25/html/jls-17.html)、[虚拟线程](https://dev.java/learn/new-features/virtual-threads/)、[JVM 规范](https://docs.oracle.com/javase/specs/jvms/se25/html/jvms-2.html)、[GC 选择](https://docs.oracle.com/en/java/javase/25/gctuning/available-collectors.html)。

### 6—11．服务端工程主干

| 领域与阶段 | 知识点 | 验收目标 |
| --- | --- | --- |
| 6．开发工具与构建（A） | IDE 调试、条件断点、调用栈；Git 分支、合并、回退与审查；Maven 生命周期、依赖传递、版本冲突、scope、BOM、插件、多模块、Wrapper；按需学习 Gradle；日志、配置、文档、依赖升级、可重复构建 | 新环境能够构建、测试并运行项目；定位一次依赖冲突 |
| 7．网络与 Web（A → B） | TCP/IP、DNS；连接建立、超时、重传；HTTP 方法、状态码、报文头、缓存、幂等语义；TLS；Cookie、Session；跨域与浏览器同源策略；Servlet 生命周期、Filter、Listener、容器；接口契约、分页、版本、错误响应；WebSocket、HTTP/2、远程过程调用（Remote Procedure Call，RPC）按需深入 | 说明一次请求从客户端到数据库再返回的完整路径；用抓包和日志定位超时 |
| 8．关系数据库（A → B） | 关系建模、主外键、约束、范式；SQL、JOIN、聚合、子查询、窗口函数；索引、执行计划、统计信息；事务原子性、一致性、隔离性、持久性（ACID）；隔离级别、多版本并发控制（Multi-Version Concurrency Control，MVCC）、锁、死锁；预写日志（Write-Ahead Logging，WAL）、恢复；复制、备份、表结构迁移 | 使用 MySQL 或 PostgreSQL 完成建模；解释并修复慢查询与并发写冲突；不将某个数据库的实现泛化到所有数据库 |
| 9．Java 数据访问（A → B） | Java 数据库连接（Java Database Connectivity，JDBC）；DataSource、连接池、PreparedStatement、批处理、事务与资源关闭；MyBatis 映射、动态 SQL、插件；或 Jakarta Persistence / Hibernate 的实体状态、关联、脏检查、延迟加载；N+1 查询、分页、乐观锁、数据库迁移工具 | 从业务方法追到实际 SQL、连接和事务；解释框架隐藏了什么、哪些问题仍由应用负责 |
| 10．Spring 体系（A → B） | 控制反转（Inversion of Control，IoC）、依赖注入（Dependency Injection，DI）；Bean 生命周期与作用域；构造器注入；面向切面编程（Aspect-Oriented Programming，AOP）与代理；Spring MVC 请求处理、校验、异常处理；事务传播、隔离、回滚和代理边界；Spring Boot 自动配置、条件装配、配置绑定、Starter、Actuator；Spring Security；WebFlux、响应式背压与 Spring Cloud 按需深入 | 完成可测试的单体服务；解释自动配置生效原因、一次请求的调用链及事务未生效的原因 |
| 11．软件设计与架构（A 持续练习，B 深入） | 职责、内聚、耦合、封装、依赖方向；接口与错误模型；不变量、状态机；策略、工厂、适配器、装饰器、代理、观察者等模式；分层、模块化单体、领域边界；领域驱动设计（Domain-Driven Design，DDD）的实体、值对象、聚合、限界上下文；架构决策记录（Architecture Decision Record，ADR）；兼容性、演进与迁移 | 对一个真实需求给出简单设计；说明边界、约束、替代方案与成本；用测试验证变更影响 |

依据：[一手] [Maven 构建生命周期](https://maven.apache.org/guides/introduction/introduction-to-the-lifecycle.html)、[HTTP 语义](https://www.rfc-editor.org/rfc/rfc9110.html)、[PostgreSQL 文档](https://www.postgresql.org/docs/current/index.html)、[并发控制](https://www.postgresql.org/docs/current/mvcc.html)、[MyBatis](https://mybatis.org/mybatis-3/)、[Hibernate](https://hibernate.org/orm/documentation/)、[Spring Framework](https://docs.spring.io/spring-framework/reference/overview.html)、[Spring Boot](https://docs.spring.io/spring-boot/reference/index.html)、[Spring Modulith 模块边界](https://docs.spring.io/spring-modulith/reference/fundamentals.html)。模式、优先级与验收项是课程组织建议。

### 12—18．生产系统能力

| 领域与阶段 | 知识点 | 验收目标 |
| --- | --- | --- |
| 12．缓存（B） | 本地缓存与 Redis；数据结构、键设计、过期、淘汰；缓存命中率；缓存穿透、击穿、雪崩；更新与失效策略、数据一致性；热点、大键；持久化、复制、故障切换、集群；分布式锁的租约与失效条件 | 解释什么能缓存、允许多久不一致、缓存失效后系统如何承受流量 |
| 13．消息与事件（B） | 队列与发布订阅；生产、存储、消费；确认、重试、死信、积压；分区、消费者组与顺序；至少一次等投递语义；去重与幂等；事务消息的适用范围；Outbox 与业务事务；消息格式演进 | 验证重复投递、消费失败、重启与乱序；说明业务结果能保证到哪一层 |
| 14．分布式系统（B → C） | 部分失败；超时、重试、退避与抖动；幂等；一致性模型；网络分区下的一致性与可用性取舍；复制、分片、选主、Raft；发现、配置、负载均衡、网关；限流、熔断、隔离、降级；两阶段提交、Saga、补偿、Outbox；时钟、租约、隔离令牌；分布式 ID；微服务边界 | 通过故障实验说明网络超时、节点重启和重复请求的结果；在有明确收益时拆分服务 |
| 15．测试与质量（A 起贯穿） | 单元、集成、接口契约、端到端测试；JUnit、断言、参数化；测试替身与边界；Testcontainers；数据库与消息集成测试；属性测试；并发与性能测试；静态检查、覆盖率的局限；失败用例与回归；测试数据隔离 | 测试能发现真实业务错误，且结果稳定；关键事务和失败路径有可重复验证 |
| 16．可观测性与性能（A 基础，B 深入） | 结构化日志、指标、链路追踪、上下文传播；OpenTelemetry；延迟分位数、吞吐量、错误率、饱和度；服务等级指标（Service Level Indicator，SLI）与服务等级目标（Service Level Objective，SLO）；jcmd、JDK Flight Recorder（JFR）、线程与堆分析、火焰图；JMH 微基准的预热、死代码消除与重复测量；负载测试、容量评估、故障复盘 | 建立负载与性能基线；形成“现象—证据—原因—修改—复测”的诊断报告 |
| 17．应用安全（A 起贯穿，C 可专精） | 认证、授权、会话管理的边界；Spring Security；OAuth 2.0、OpenID Connect、JWT 校验；访问控制、越权；SQL 注入、跨站脚本、跨站请求伪造、服务端请求伪造；反序列化、路径和文件上传安全；密码存储、随机数、密钥管理、TLS、证书信任；依赖漏洞、敏感日志、审计；Java 密码服务与 Provider 按需深入 | 用失败用例验证越权、非法输入与令牌校验；审查密钥和敏感信息的生命周期 |
| 18．部署与交付（A 单机，B 容器与集群） | Linux 进程、权限、网络与日志排查；应用配置、打包、健康检查、优雅停机；持续集成（Continuous Integration，CI）与持续交付（Continuous Delivery，CD）；镜像、容器、资源限制；Kubernetes 的 Pod、Deployment、Service、配置、探针、扩缩容；滚动发布、回滚、备份恢复 | 在干净环境交付服务；验证重启、资源不足、发布和回滚；说明应用与平台各自负责什么 |

依据：[一手] [Redis](https://redis.io/docs/latest/develop/)、[Kafka 设计](https://kafka.apache.org/42/design/design/)、[Raft 作者项目](https://raft.github.io/)、[Spring Cloud](https://spring.io/projects/spring-cloud/)、[JUnit](https://docs.junit.org/current/user-guide/)、[Testcontainers](https://java.testcontainers.org/)、[OpenTelemetry](https://opentelemetry.io/docs/concepts/)、[JDK 诊断工具](https://docs.oracle.com/en/java/javase/25/troubleshoot/diagnostic-tools.html)、[JMH](https://github.com/openjdk/jmh)、[Spring Security](https://docs.spring.io/spring-security/reference/index.html)、[Java 安全编码指南](https://www.oracle.com/java/technologies/javase/seccodeguide.html)、[Kubernetes](https://kubernetes.io/docs/concepts/)。

### 专项方向（C）：选择一个深入，不要求全部精通

| 方向 | 深入内容与成果 |
| --- | --- |
| JVM 与性能 | 编译与 GC、内存与并发、操作系统与硬件；定位跨层瓶颈；形成带条件与数据的诊断、优化报告 |
| 框架与基础设施 | Spring 扩展点、注解处理、字节码增强、Java Agent、网络框架、库的兼容性；实现并维护可复用组件 |
| 分布式与数据系统 | 共识、存储、复制、恢复、调度、消息、容量与可用性；实现故障注入实验并解释正确性边界 |
| 安全与业务领域 | Java 密码 API、证书信任、密钥生命周期、签名验证与审计；结合当前国密、电子签章、PKI 工作深入标准和实现 |
| 启动与部署优化 | 提前编译（Ahead-of-Time Compilation，AOT）、GraalVM Native Image、运行时裁剪、启动与内存预算；比较兼容性和运维成本 |

搜索引擎、文档数据库、批处理、任务调度、工作流、大数据、桌面 JavaFX、Android 等属于按产品需求追加的分支。进入分支后另查对应官方资料，不将品牌清单作为主干完成标准。[一手] [GraalVM Native Image](https://www.graalvm.org/latest/reference-manual/native-image/)；[JDK 工具与技术目录](https://docs.oracle.com/en/java/javase/25/)。

### 阶段验收与学习方法

| 阶段 | 学习重点 | 可验证产出 |
| --- | --- | --- |
| 第一阶段 | Java SE、基本算法、Git、Maven、JUnit | 不依赖 Spring 的命令行文件处理工具，包含正常、异常与边界测试 |
| 第二阶段 | HTTP、数据库、数据访问、Spring、基础安全 | 模块化单体服务，包含权限、事务、迁移、错误处理和集成测试 |
| 第三阶段 | 并发、JVM、操作系统、可观测性 | 在测试环境制造内存泄漏、锁竞争和线程池耗尽，保存证据并完成修复 |
| 第四阶段 | 缓存、消息、分布式、部署 | 为明确需求引入缓存或消息；验证重复、丢连接、重启、积压与回滚 |
| 第五阶段 | 一个专家专项、源码与规范 | 完成可复现的深入分析、组件改进或开源贡献，接受他人审查 |

每个知识点按五步学习：明确要解决的问题 → 编写最小实验 → 查 API、规范和实现 → 注入边界或故障 → 写明适用条件与取舍。源码沿问题阅读，例如 HashMap 查找与扩容、ThreadPoolExecutor 任务提交与拒绝、Spring Bean 创建与事务代理；不要求从仓库第一行通读。架构、测试、安全和文档从第一阶段开始，不等后期补做。

既有记录的衔接：认证与会话的知识用于第 7、17 领域；Docker 与 Kubernetes 的分工用于第 18 领域。本次新增的是完整 Java 能力地图，不展开或修正上述领域的历史演化结论。

### 首要资料

- [一手] [Dev.java：语言与标准库学习入口](https://dev.java/learn/)
- [一手] [Java 语言与虚拟机规范](https://docs.oracle.com/javase/specs/)
- [一手] [JDK 文档：工具、GC、安全与诊断](https://docs.oracle.com/en/java/javase/25/)
- [一手] [Spring Framework 官方文档](https://docs.spring.io/spring-framework/reference/overview.html)
- [一手] [Spring Boot 官方文档](https://docs.spring.io/spring-boot/reference/index.html)
- [一手] [PostgreSQL 官方文档](https://www.postgresql.org/docs/current/index.html)

## 2026-09-23 · Java 日志的系统学习路线与知识地图
- **问**：系统性学习 Java 日志的学习路线，以及全部知识点。
- **答**：以 Java/Spring 服务端为范围，按“事件与级别 → API 与实现 → 正确记录与配置 → 生产采集、安全和性能 → 故障诊断”推进。Spring Boot Starter 默认用 Logback；应用可先掌握 SLF4J 与 Logback，再按实际依赖了解 JUL、System.Logger 和 Log4j 2。完整知识地图见下文；阶段划分及练习是学习建议，并非官方课程。
- **信源**：[一手] [JDK 21 JUL](https://docs.oracle.com/en/java/javase/21/core/java-logging-overview.html)；[SLF4J 手册](https://www.slf4j.org/manual.html)；[Spring Boot 3.5 日志](https://docs.spring.io/spring-boot/3.5/reference/features/logging.html)；[Logback 手册](https://logback.qos.ch/manual/)；[Log4j 2 架构](https://logging.apache.org/log4j/2.x/manual/architecture.html)；[OpenTelemetry 日志模型](https://opentelemetry.io/docs/specs/otel/logs/data-model/)；[OWASP 日志指南](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html)。核实日期：2026-09-23。

### 学习路线与验收

| 阶段 | 学习内容 | 可验证产出 |
| --- | --- | --- |
| 1．事件基础 | 何时记日志；事件、级别、时间、来源、异常、上下文；日志与指标、链路追踪、审计的用途 | 对同一请求写出正常、失败、安全事件，并说明级别与字段选择 |
| 2．API 与实现 | JUL、System.Logger、SLF4J；Provider、Logback/Log4j 2；依赖与单向桥接 | 画出当前项目从日志调用到输出的路径；排除缺 Provider、重复输出和桥接循环 |
| 3．应用写法与配置 | 参数化、异常原因链、MDC；层级、级别、Appender、Filter、Layout、Encoder；Spring Boot 配置 | 在测试环境按包调整级别，输出可检索事件与完整异常，并验证 MDC 清理 |
| 4．生产链路 | JSON 字段模式、轮转与保留、容器输出、采集器、检索、权限、脱敏、容量、异步队列 | 使一条请求日志可按 traceId 定位；模拟磁盘/队列压力并观察丢失或阻塞 |
| 5．诊断与专项 | 日志缺失/重复/乱序、启动期配置、跨线程上下文、JVM `-Xlog`、审计日志 | 用证据定位一次日志故障；将 JVM GC 日志与应用事件区分 |

### 知识点清单

| 主题 | 应掌握的知识点 |
| --- | --- |
| 事件模型 | 应用业务日志、HTTP 访问日志、框架/SQL 日志、JVM 日志与审计日志的来源和用途；时间戳与时区、级别、logger 名、线程、消息模板与参数、异常堆栈、键值属性、服务标识、requestId/traceId/spanId；事件语义与字段类型稳定性 |
| API 与依赖 | `System.out/err`、JUL 的 Logger/LogRecord/Handler/Formatter、`System.Logger`；SLF4J 门面与 2.x Provider；Logback、Log4j 2；依赖传递、版本匹配、绑定诊断、桥接方向 |
| 记录规则 | TRACE/DEBUG/INFO/WARN/ERROR 选择；事件位置与频率；参数化 `{}`、惰性参数、`Throwable` 末参或 `setCause`；避免同一异常在多层重复记录；日志内容可定位且不泄密 |
| 实现与配置 | Logger 层级和有效级别、additivity、Filter、Appender、Layout/Encoder；控制台、文件、滚动文件；格式、字符集、时区；配置文件、环境变量、profile、运行时级别、启动顺序 |
| 上下文与并发 | 映射诊断上下文（Mapped Diagnostic Context，MDC）；请求范围设值与清理；线程池、`CompletableFuture`、虚拟线程与响应式链路的上下文传播；跨服务 trace/span 关联 |
| 结构化与采集 | JSON 与字段模式；机器可检索字段、异常序列化；标准输出/错误输出、文件；容器日志轮转、节点采集器、Collector 的接收/处理/导出、存储索引、查询与告警、保留期和成本 |
| 性能与可靠性 | 关闭级别时的计算成本、高频日志和堆栈成本；同步/异步写入、有界队列、背压/阻塞/丢弃、停机冲刷；磁盘空间、文件轮转、流量预算与故障模式 |
| 安全与审计 | 认证/授权及关键操作事件；口令、令牌、密钥、会话标识与敏感个人信息的屏蔽；日志注入与换行转义；访问控制、完整性、保留与删除；审计事件的完整性要求 |
| 验证与排障 | 捕获并断言关键事件；验证无敏感字段与完整异常；依赖树、初始化日志、有效级别、重复 Appender、MDC 泄漏、队列压力、采集链路中断；JVM `-Xlog` 与应用日志的来源区别 |

### 易错边界

- JUL / `System.Logger` 的参数格式使用 `{0}`，SLF4J 使用 `{}`；跨 API 搬代码必须改格式。[一手] [JDK 21 System.Logger](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/System.Logger.html)、[SLF4J 手册](https://www.slf4j.org/manual.html)。
- SLF4J 2.x 通过 `ServiceLoader` 找 Provider；未找到时可能成为无操作日志。JUL→SLF4J 与 SLF4J→JUL 的桥接不能同时组成闭环。[一手] [SLF4J 错误说明](https://www.slf4j.org/codes.html)、[桥接说明](https://www.slf4j.org/legacy.html)。
- 参数化日志推迟格式化，但不会推迟 Java 实参表达式求值；昂贵参数可用 SLF4J 2.x Fluent API 的 `Supplier`。`MDC.putCloseable` 关闭时移除键，不恢复同名键旧值。[一手] [SLF4J 手册](https://www.slf4j.org/manual.html)、[MDC API](https://www.slf4j.org/api/org/slf4j/MDC.html)。
- Spring Boot 3.4 起提供内置结构化日志格式；自定义 Logback 配置需采用对应 Encoder 才能使 `logging.structured.format.*` 生效。Logback `AsyncAppender` 默认可能在队列逼近满载时丢弃低级别事件。[一手] [Spring Boot 3.4 发布说明](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-3.4-Release-Notes)、[Spring Boot 3.5 日志](https://docs.spring.io/spring-boot/3.5/reference/features/logging.html)、[Logback 异步 Appender](https://logback.qos.ch/manual/appenders-async-sift.html)。
- 应用日志与 JVM 统一日志配置入口不同；GC 等 JVM 日志通过 `-Xlog` 控制。容器中优先掌握标准输出及平台的轮转、采集链路。[一手] [JDK 21 `java` 命令](https://docs.oracle.com/en/java/javase/21/docs/specs/man/java.html)、[Kubernetes 日志架构](https://kubernetes.io/docs/concepts/cluster-administration/logging/)。

### 最小综合练习

用一个 Spring Boot 服务记录“签章请求接收、成功、失败”三类事件。配置包级日志级别和 JSON 控制台输出；用 MDC 或等价上下文附上请求关联 ID；失败事件保留异常堆栈，验证日志中没有私钥、令牌或原文文档。随后分别测试线程池任务、异步队列压力和服务重启，检查关联字段、事件完整性与采集结果。签章业务字段及哪些事件属于正式审计，应再按项目适用规范确定。[一手] [OpenTelemetry 日志关联](https://opentelemetry.io/docs/specs/otel/logs/)、[OWASP 日志指南](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html)。

## 2026-09-23 · JVM 的系统学习路线与知识地图
- **问**：制定 JVM 的学习路线，以及需要掌握的全部知识点。
- **答**：面向 Java 服务端开发，依次学习 JVM 规范与字节码、类的生命周期、运行时内存与对象、HotSpot GC 与编译、并发语义，最后用 JFR、`jcmd`、GC 日志和转储完成故障诊断。类文件、运行时语义和内存模型由规范定义；内存物理布局、GC 算法及 JIT 优化属于具体实现。下列阶段与验收是学习建议，不是官方统一课程。
- **信源**：[一手] [Java SE 27 JVM 规范](https://docs.oracle.com/javase/specs/jvms/se27/html/index.html)；[Java SE 27 语言规范第 17 章](https://docs.oracle.com/javase/specs/jls/se27/html/jls-17.html)；[JDK 21 HotSpot GC 指南](https://docs.oracle.com/en/java/javase/21/gctuning/)；[JDK 21 虚拟机指南](https://docs.oracle.com/en/java/javase/21/vm/)；[JDK 21 诊断工具](https://docs.oracle.com/en/java/javase/21/troubleshoot/diagnostic-tools.html)。核实日期：2026-09-23。

### 学习路线

前置：会用 Java SE 编写多线程程序；理解进程、线程、虚拟内存、CPU 缓存和基本数据结构。实验以当前环境的 JDK 21 为主，规范先看相应版本；Java SE 27 规范可用于核对最新术语，跨版本比较时核查行为和参数。[一手] [Java SE 21 JVM 规范](https://docs.oracle.com/javase/specs/jvms/se21/html/index.html)、[Java SE 支持路线图](https://www.oracle.com/java/technologies/java-se-support-roadmap.html)。

| 阶段 | 为什么先学这一层 | 最小实验与通过标准 |
| --- | --- | --- |
| 1．字节码与类文件 | 建立“源码如何成为可执行输入”的模型 | 用 `javac`、`javap -c -v` 对照循环、异常、Lambda、`synchronized` 的源码和 `class`；能说明常量池、栈帧和调用指令的作用 |
| 2．类加载与运行时 | 弄清类何时可用、对象和方法在哪里运行 | 写两个类加载器加载同名类；追踪加载、验证、准备、解析、初始化；能解释类身份、初始化顺序与失败 |
| 3．内存与 GC | 先识别“谁还活着”，再研究回收器 | 制造对象滞留和小堆压力；记录 GC 日志与堆转储；能区分对象分配过快、存活对象过多与非堆内存增长 |
| 4．编译与并发 | 理解同一程序的执行速度与可见性为何变化 | 用 JFR 观察热点、分配和锁；用并发小程序证明 happens-before；能解释预热、内联、反优化、平台线程和虚拟线程 |
| 5．诊断与调优 | 把模型用于实际服务，而非记参数 | 对 CPU 高、延迟升高、内存增长、线程阻塞各做一次复现实验；保留现象、证据、原因、改动和复测结果 |
| 6．实现专项（选学） | 根据工作问题深入某个实现机制 | 选 GC、编译器、类加载/Agent 或 Native 接口；阅读对应 OpenJDK 源码，并用实验说明适用 JDK 与实现 |

### 知识点总表

“核心”指能解释机制并诊断常见生产问题；“深入”指进入 JVM 专项时再学习。指令、属性和 `-XX` 参数按家族理解，遇到问题查对应版本文档，不要求背全表。

| 主题 | 核心知识点 | 深入知识点及一手依据 |
| --- | --- | --- |
| 边界与版本 | JDK、JRE、JVM、Java SE 规范与 HotSpot 的关系；JDK 版本、发行版、启动参数和默认值的适用范围 | JVMS 将物理布局、GC 和指令优化留给实现。[JVMS §2.13](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-2.html) |
| 类文件 | `ClassFile` 结构、版本、常量池、符号引用、名称与描述符、字段/方法、`Code`、异常表、`StackMapTable`、字节码校验 | `BootstrapMethods`、`MethodHandle`、`invokedynamic`、动态常量、注解、模块及现代属性；二进制兼容。[JVMS 第 4 章](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-4.html)、[JLS 第 13 章](https://docs.oracle.com/javase/specs/jls/se27/html/jls-13.html) |
| 指令与调用 | 局部变量表、操作数栈；常量、加载/存储、算术/转换、对象/数组、分支、字段访问、方法调用、返回、异常、监视器各类指令；动态分派 | 五种调用指令及解析/选择规则，`invokedynamic` 调用点；按单条指令语义查证。[JVMS 第 2、6 章](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-2.html)、[指令集](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-6.html) |
| 类生命周期 | 启动、加载器和类身份；加载→验证/准备/解析→初始化；`<clinit>`、访问控制、父类初始化、初始化失败、类卸载 | 加载约束、模块层、自定义加载器、延迟解析、类加载泄漏、CDS。[JVMS 第 5 章](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-5.html)、[CDS](https://docs.oracle.com/en/java/javase/21/vm/class-data-sharing.html) |
| 运行时数据区 | `pc`、JVM 栈、栈帧、堆、方法区、运行时常量池、本地方法栈；`StackOverflowError` 与各类 `OutOfMemoryError` 的区别 | HotSpot 元空间、压缩类空间、代码缓存、线程栈及本机内存；方法区是规范概念，不能直接等同于元空间。[JVMS §2.5](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-2.html)、[内存泄漏排查](https://docs.oracle.com/en/java/javase/21/troubleshoot/troubleshooting-memory-leaks.html) |
| 对象与引用 | 分配与可达性、GC Roots、强/软/弱/虚引用、`ReferenceQueue`、`Cleaner`；对象滞留与内存泄漏 | 对象布局、压缩引用、线程本地分配缓冲区、直接内存和本机内存；布局随实现/版本变化。[引用 API](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/ref/package-summary.html)、[HotSpot 优化](https://docs.oracle.com/en/java/javase/21/vm/java-hotspot-virtual-machine-performance-enhancements.html) |
| GC | 标记、清除、复制、压缩；分代假说、并行/并发、停顿；分配率、存活集、吞吐量和停顿；Serial、Parallel、G1、ZGC 的目标与取舍 | G1 的 Region、Remembered Set、写屏障、混合回收；ZGC 的并发机制；安全点、类卸载、碎片与大对象。先用默认设置建立基线，再按目标调节。[JDK 21 GC 指南](https://docs.oracle.com/en/java/javase/21/gctuning/)、[JDK 27 回收器列表](https://docs.oracle.com/en/java/javase/27/gctuning/available-collectors.html) |
| 执行与 JIT | 解释执行、热点探测、分层编译、C1/C2、即时编译（Just-In-Time Compilation，JIT）、预热、内联、栈上替换、反优化、代码缓存 | 逃逸分析、标量替换、锁消除、编译器指令与机器码观察、基准测试陷阱。[HotSpot 性能增强](https://docs.oracle.com/en/java/javase/21/vm/java-hotspot-virtual-machine-performance-enhancements.html) |
| 并发语义 | Java 内存模型（Java Memory Model，JMM）；同步顺序、happens-before、数据竞争；`synchronized`、`volatile`、`final`、`wait/notify`、中断、原子类、`VarHandle` | 锁实现、安全点、平台线程与虚拟线程的调度和诊断；区分内存模型与运行时内存区域。[JLS 第 17 章](https://docs.oracle.com/javase/specs/jls/se27/html/jls-17.html)、[JDK 21 虚拟线程](https://docs.oracle.com/en/java/javase/21/core/virtual-threads.html) |
| 系统边界 | Java 堆、直接内存、线程栈、本机内存、进程驻留内存的关系；CPU、文件、网络及容器资源限制对服务的影响 | JNI、Foreign Function & Memory API、JVMTI、Agent、操作系统采样及崩溃文件分析；NMT 不覆盖第三方本机分配。[NMT](https://docs.oracle.com/en/java/javase/21/vm/native-memory-tracking.html)、[JVMTI](https://docs.oracle.com/en/java/javase/25/docs/specs/jvmti.html)、[Java Agent API](https://docs.oracle.com/en/java/javase/21/docs/api/java.instrument/java/lang/instrument/package-summary.html)、[Foreign Function & Memory API](https://docs.oracle.com/en/java/javase/25/core/foreign-function-and-memory-api.html) |
| 观测与故障 | `-Xlog` 统一日志；`jcmd` 的 `VM.flags`、`GC.heap_info`、`GC.class_histogram`、`GC.heap_dump`、`Thread.print`、`JFR.start`；JFR、JMC、`jfr`、线程/堆转储；CPU、吞吐量、延迟分位数、GC 停顿和内存趋势 | NMT 基线与差分；`jstat`、`jstack`、`jmap`、`jhsdb` 的适用条件和风险；JFR 自定义事件。堆转储可能高影响，诊断工具应与目标 JDK 版本匹配。[诊断工具](https://docs.oracle.com/en/java/javase/21/troubleshoot/diagnostic-tools.html)、[`jcmd` 手册](https://docs.oracle.com/en/java/javase/25/docs/specs/man/jcmd.html)、[`java` 手册](https://docs.oracle.com/en/java/javase/25/docs/specs/man/java.html) |

### 关键边界与综合练习

- JVM 规范的“方法区”是逻辑区域；HotSpot 元空间是具体实现中的类元数据存储。JMM 约束多线程可观察行为，不是“堆和栈的分区图”。[一手] [JVMS 第 2 章](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-2.html)、[JLS 第 17 章](https://docs.oracle.com/javase/specs/jls/se27/html/jls-17.html)。
- JVMS 第 5 章将 `static` 字段的默认值赋予准备阶段，将 `ConstantValue` 赋值与 `<clinit>` 放在初始化阶段；不要把口诀当成规范。[一手] [JVMS §5.4.2、§5.5](https://docs.oracle.com/javase/specs/jvms/se27/html/jvms-5.html)。
- GC 与诊断参数要按 JDK 版本核对；例如 JDK 21 的分代 ZGC 参数不能直接照搬到 JDK 25。[一手] [JDK 21 GC 指南](https://docs.oracle.com/en/java/javase/21/gctuning/)、[JDK 25 GC 指南](https://docs.oracle.com/en/java/javase/25/gctuning/)。

最小综合练习：在测试环境给同一个小型 Java 服务制造对象滞留、频繁分配、锁竞争及大量类加载四种现象。每次只改变一个条件；采集 GC 日志、JFR 与相应转储；写出“现象 → 证据 → 原因 → 调整 → 复测”，并记录 JDK、GC、堆参数、负载和测量窗口。只有当复测显示目标指标改善，才把调整视为有效。诊断步骤依据 [一手] [JDK 21 诊断工具](https://docs.oracle.com/en/java/javase/21/troubleshoot/diagnostic-tools.html)、[G1 调优建议](https://docs.oracle.com/en/java/javase/21/gctuning/garbage-first-garbage-collector-tuning.html)。

### 首要资料

- [一手] [Java SE 27 JVM 规范](https://docs.oracle.com/javase/specs/jvms/se27/html/index.html)
- [一手] [Java SE 27 语言规范：线程与锁](https://docs.oracle.com/javase/specs/jls/se27/html/jls-17.html)
- [一手] [JDK 21 HotSpot GC 指南](https://docs.oracle.com/en/java/javase/21/gctuning/)
- [一手] [JDK 21 虚拟机指南](https://docs.oracle.com/en/java/javase/21/vm/)
- [一手] [JDK 21 诊断工具](https://docs.oracle.com/en/java/javase/21/troubleshoot/diagnostic-tools.html)

## 2026-10-14 · Java EE 与 Tomcat 的关系及名称演变
- **问**：Java EE 和 Tomcat 之间是什么关系？为什么 Tomcat 听得多而很少听到 Java EE？
- **答**：Java EE（现 Jakarta EE）是一组规范，不是软件；Tomcat 是实现其中 Web 层子集（Servlet、JSP、EL、WebSocket）的开源 Servlet 容器。完整实现全部规范的软件叫应用服务器（GlassFish、WildFly、WebLogic 等）。Tomcat 高频出现是因为它是可安装运行的具体产品、Web 子集的事实标准且被 Spring Boot 默认内嵌；"Java EE"之名已停用（J2EE → Java EE → Jakarta EE），完整平台话题又被 Spring 分流。
- **信源**：[一手] [Apache Tomcat 版本与规范对应](https://tomcat.apache.org/whichversion.html)；[Jakarta EE 官网](https://jakarta.ee/)；[Jakarta EE About](https://jakarta.ee/about/)；[Eclipse Foundation 博客：Java EE Moves to the Eclipse Foundation（2017-09-12）](https://eclipse-foundation.blog/2017/09/12/java-ee-moves-to-the-eclipse-foundation)。核实日期：2026-10-14。
- **关联**：[[Java#2026-09-22 · 成为 Java 专家的完整学习路线]]

### 名称与归属演变

```mermaid
timeline
    title 企业 Java 平台名称与归属演变
    1999 : Sun 发布 J2EE 1.2
    2006 : J2EE 更名 Java EE（Java EE 5 起）
    2017 : Oracle 将 Java EE 移交 Eclipse 基金会（EE4J 项目）
    2019 : 更名 Jakarta EE，首版 Jakarta EE 8 与 Java EE 8 规范一致
    2020 : Jakarta EE 9 起，命名空间 javax 改为 jakarta
    2026 : Tomcat 11 对应 Jakarta EE 11 的 Web 层规范
```

Tomcat 与规范版本对应（[一手](https://tomcat.apache.org/whichversion.html)）：Tomcat 9 ↔ Java EE 8（Servlet 4.0，最后一个支持 `javax` 命名空间的大版本）；Tomcat 10.1 ↔ Jakarta EE 10（Servlet 6.0）；Tomcat 11 ↔ Jakarta EE 11（Servlet 6.1）。
