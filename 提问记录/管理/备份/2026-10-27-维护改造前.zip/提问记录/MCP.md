# MCP

## 综述

模型上下文协议（Model Context Protocol，MCP）的学习主线是：编程与通信基础 → 架构和接入 → 服务器三种核心能力 → 消息、版本和传输 → 交互机制 → 客户端与宿主应用 → 授权安全 → 测试部署 → 官方扩展、旧版兼容和源码。2026-10-25 核实的现行规范为 2026-07-28：核心请求无状态，以每请求 `_meta` 声明版本和客户端能力，服务器必须实现 `server/discover`，客户端可以选择是否先调用；多轮往返请求（Multi Round-Trip Requests，MRTR）替代独立的服务端反向请求，变更通知使用 `subscriptions/listen`。核心能力是 Tools、Resources、Prompts，用户补充信息使用 Elicitation；Tasks、MCP Apps、Skills over MCP 和授权增强属于需双方显式支持的扩展。旧版 initialize 握手、协议会话、HTTP GET 通知流和 SSE 断线续传属于兼容知识；Roots、Sampling、Logging 和动态客户端注册 DCR 已弃用但仍在过渡期。npx 是启动命令，stdio 与 Streamable HTTP 才是传输；HTTP 也可运行在本机，SSE 仍用于当前 HTTP 传输，stdio 不强制工具串行执行。掌握程度应通过服务器、客户端、授权、多用户隔离和故障恢复项目验收；具体宿主和 SDK 的版本及扩展支持需要逐项核对。

## 2026-10-25 · 系统学习 MCP 的完整路线与知识点
- **问**：我希望系统性学习 mcp，给出完整学习路线和全部需要学习的知识点。
- **答**：按“会接入 → 会写服务器 → 理解协议 → 会写客户端和宿主 → 安全上线 → 扩展与兼容”推进，知识清单覆盖编程与通信前置、架构、三种服务端能力、每请求元数据和发现、两种标准传输、MRTR、订阅与通用机制、宿主编排、授权安全、工程运维和官方扩展。以 2026-07-28 规范为主，旧握手、会话和弃用特性单列；路线与项目验收是学习建议，不是规范要求所有应用实现全部可选能力。
- **信源**：[一手] [现行规范](https://modelcontextprotocol.io/specification/2026-07-28)；[一手] [版本变更](https://modelcontextprotocol.io/specification/2026-07-28/changelog)；[一手] [架构](https://modelcontextprotocol.io/docs/2026-07-28/learn/architecture)；[一手] [基础消息](https://modelcontextprotocol.io/specification/2026-07-28/basic)；[一手] [规范类型源码](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/schema/2026-07-28/schema.ts)；[一手] [工具](https://modelcontextprotocol.io/specification/2026-07-28/server/tools)；[一手] [资源](https://modelcontextprotocol.io/specification/2026-07-28/server/resources)；[一手] [提示模板](https://modelcontextprotocol.io/specification/2026-07-28/server/prompts.md)；[一手] [stdio](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/stdio)；[一手] [Streamable HTTP](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/streamable-http)；[一手] [MRTR](https://modelcontextprotocol.io/specification/2026-07-28/basic/patterns/mrtr)；[一手] [订阅](https://modelcontextprotocol.io/specification/2026-07-28/basic/patterns/subscriptions.md)；[一手] [Elicitation](https://modelcontextprotocol.io/specification/2026-07-28/client/elicitation)；[一手] [授权](https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization)；[一手] [安全最佳实践](https://modelcontextprotocol.io/docs/2026-07-28/tutorials/security/security_best_practices)；[一手] [本地服务器安全](https://modelcontextprotocol.io/docs/2026-07-28/tutorials/security/local-server-security)；[一手] [客户端最佳实践](https://modelcontextprotocol.io/docs/2026-07-28/develop/clients/client-best-practices)；[一手] [官方 SDK](https://modelcontextprotocol.io/docs/2026-07-28/sdk)；[一手] [Inspector](https://modelcontextprotocol.io/docs/2026-07-28/tools/inspector)；[一手] [扩展总览](https://modelcontextprotocol.io/extensions/overview)；[一手] [Tasks](https://modelcontextprotocol.io/extensions/tasks/overview)；[一手] [MCP Apps](https://modelcontextprotocol.io/extensions/apps/overview)；[一手] [Skills over MCP](https://modelcontextprotocol.io/extensions/skills/overview)；[一手] [Registry](https://modelcontextprotocol.io/registry/about)。
- **关联**：[[AI 编程#2026-10-20 · MCP 服务器接入方式：npx 本地与 HTTP 远程的选择]]；[[AI 编程#2026-10-20 · 将 WASM 封装为 MCP 供 Agent 调用的可行性与形态]]；[[AI 编程#2026-10-20 · DWG 处理 WASM 云端部署的并发与 C++ 替代问题]]

### 完整知识清单

1. **前置基础**：任选一门有官方 SDK 的语言；包管理、类型、异步、异常、测试、进程、标准流、环境变量；JSON、JSON Schema 2020-12、JSON-RPC 2.0、HTTP、SSE；模型工具调用与上下文限制。
2. **架构**：Host、Client、Server 的职责；数据层与传输层；发现、调用、上下文装配和模型执行的关系；与普通 API、函数调用、检索增强生成、Agent Skills 的分工。
3. **接入**：command、args、env、工作目录、路径、配置作用域；本地 stdio、本地 HTTP、远程 HTTP；供应链、版本固定和凭据管理；Inspector 查看原始消息与排障。
4. **服务器能力**：tools/list、tools/call；输入输出 Schema、structuredContent、isError、工具提示注解；resources/list、resources/read、resources/templates/list；URI、模板、文本与二进制；prompts/list、prompts/get、参数和消息；文字、图像、音频、资源链接及嵌入资源；title、description、icons、annotations、_meta。
5. **基础协议**：请求、结果、错误和通知；请求 ID、并发关联、乱序返回；每请求版本、身份和能力；server/discover；resultType；JSON-RPC 错误与工具执行错误；Schema 的 $ref、组合和验证资源限制。
6. **传输**：stdio 的换行分帧、UTF-8、stdout 纯协议、stderr 日志、子进程生命周期；HTTP 单端点 POST、JSON 或请求级 SSE、内容协商；MCP-Protocol-Version、Mcp-Method、适用请求的 Mcp-Name；x-mcp-header、头体一致性和安全编码；断线、超时、取消；本地 Origin 校验和回环绑定。
7. **交互与通用机制**：MRTR 的 input_required、inputRequests、inputResponses、requestState 与重试新 ID；Elicitation 的 form/url、accept/decline/cancel 和敏感信息边界；subscriptions/listen 的过滤、确认、关联和重建；progressToken；cursor 分页；ttlMs、cacheScope 和缓存失效；completion/complete；幂等、并发与业务状态句柄。
8. **客户端与宿主**：多服务器生命周期、名字冲突、能力降级；协议工具与模型工具定义转换；工具调用循环、上下文预算、审批、最大轮数；资源与提示模板的使用；渐进式工具发现、程序化工具调用、缓存和沙箱。
9. **授权**：HTTP 下的 OAuth 角色、授权码和 PKCE、Bearer、scope、resource/audience；受保护资源和授权服务器元数据发现；CIMD、预注册、DCR 兼容；令牌存取刷新、step-up、issuer 和重定向校验；区分客户端到 MCP 与 MCP 到下游 API 的凭据；stdio 的进程环境凭据。
10. **安全**：最小权限、服务端逐请求鉴权、多租户隔离、句柄归属；提示注入、工具描述投毒、内容和注解不可信；供应链和本地进程隔离；SSRF、DNS rebinding、confused deputy、token passthrough、凭据泄露和审计。
11. **工程化**：契约与集成测试、多宿主互操作、失败注入和模型选择工具的评测；连接与执行并发、限流、排队、背压、重试退避、幂等去重；网关、TLS、反向代理 SSE 缓冲与超时、水平扩展；OpenTelemetry、日志脱敏、延迟与错误指标；版本发布、Registry 元数据、文档和迁移策略。
12. **扩展、兼容与源码**：扩展标识和能力协商；Tasks 的 task 结果类型与 tasks/get、tasks/update、tasks/cancel、持久化和中途输入；MCP Apps 的界面资源、宿主通信和界面安全；Skills over MCP 的资源式发现与读取；OAuth Client Credentials 与 Enterprise-Managed Authorization；旧 initialize、session、GET 流、resources/subscribe、ping、tasks/result/list 和断线续传；Roots、Sampling、Logging、DCR 的弃用迁移；schema.ts、SDK 分层、协议实现与规范增强提案 SEP。

### 项目验收建议

- 接入实验：同一服务器分别通过 stdio 与 HTTP 调用，用 Inspector 解释完整报文。
- 个人知识库服务器：搜索工具、文档资源、总结提示模板，覆盖分页、Schema 和错误。
- 自建宿主：连接至少两个服务器，完成工具调用循环，处理同名工具、超时和用户拒绝。
- 授权远程服务：完成 OAuth、两个用户的数据隔离、权限不足和令牌过期测试。
- 长任务与扩展：批处理任务可轮询、取消、中途补充输入和客户端重启后继续；支持时增加一个 MCP App 或 Skill。
- 迁移与部署：对比当前和一个旧版客户端；验证重试不会重复写入，输出部署、监控和升级说明。
