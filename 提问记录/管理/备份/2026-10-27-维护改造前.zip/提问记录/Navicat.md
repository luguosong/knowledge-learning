# Navicat

## 综述

Navicat 的版本查询必须区分产品、操作系统、主版本与补丁版本。截至 2026-10-26，官网最新主版本为 Navicat 18；国际官网发行说明列出的 Navicat Premium Windows 版最新补丁为 18.0.5，发布日期为 2026-10-22。中文官网发行说明当次核实时只列到 18.0.3，两个站点的记录不同；本次 18.0.5 的结论适用于国际官网所列的 Windows 版，不能直接推及其他产品或平台。

## 2026-10-26 · Navicat 最新版本
- **问**：查看 navicat 最新是哪个版本。
- **答**：截至 2026-10-26，最新主版本为 Navicat 18；国际官网列出的 Navicat Premium Windows 版最新补丁为 18.0.5，发布于 2026-10-22。中文官网当次核实只列到 18.0.3，存在站点记录差异；其他产品与操作系统的最新补丁不在本条结论范围内。
- **信源**：[一手] [Navicat 官方新闻中心：2026-09-16 发布 Navicat 18](https://www.navicat.com.cn/company/press)；[一手] [Navicat Premium 国际官网发行说明](https://www3.navicat.com/en/products/navicat-premium-release-note)；[一手] [Navicat Premium 中文官网发行说明](https://www.navicat.com.cn/products/navicat-premium-release-note)
