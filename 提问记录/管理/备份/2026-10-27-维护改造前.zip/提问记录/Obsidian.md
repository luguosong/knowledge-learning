# Obsidian

## 综述

Obsidian Tasks 在笔记内以 Markdown 清单项保存任务，通过 `tasks` 查询块跨整个仓库汇总、筛选和回写任务状态；支持日期、重复规则、优先级等字段。它适合让任务留在笔记上下文中；通知需借助其他插件。Windows 电脑与 iPhone 间免费、私有地查阅整个 vault，可在两端用 Remotely Save 插件经个人版 OneDrive 的应用文件夹同步；Microsoft 账户免费云存储共 5 GB，与其他文件等共享。手机纯查看时可选单向增量下载，若需跟随电脑删除则选带删除的下载模式；这不禁用手机编辑，手机修改可能被远端内容覆盖。该方案未经 Obsidian 官方支持，且 iOS 后台不能自动同步；先备份，再由电脑完成首次上传、手机从空 vault 下载，不让另一同步服务同时管理该 vault。Obsidian 官方提醒，Windows 上用 iCloud Drive 同步 vault 可能导致文件重复或损坏。Obsidian Git 在桌面端用本地 Git 管理版本，并可按定时器提交、拉取和推送；分离定时器后，这三项独立运行，若多设备共用 Git 仓库，单次“提交并同步”更易保证提交→拉取→推送顺序。它不等同实时同步服务；Windows 上可用 Git Credential Manager 管理远端认证，提交作者姓名和邮箱与远端认证不同。此前讨论的 OneDrive + Remotely Save 仍是 iPhone 私有查阅方案；若继续用它作为主同步，Git 更适合作为桌面端的版本历史和远端备份。Mermaid 图表美化可按需求选择：Mermaid Boost 为原生渲染结果应用多套主题并提供缩放与 PNG 导出；Slick Mermaid 跟随 Obsidian 主题，默认覆盖图中显式配色，可在设置中关闭；Auto Beautiful Mermaid 对流程图、时序图、状态图、类图、实体关系图与 XY 图使用 beautiful-mermaid，其他类型回退到原生渲染器。待解问题：与其他 Obsidian 任务插件的功能边界及个人工作流取舍。

## 2026-09-24 · Obsidian Tasks 插件的定位与基本用法
- **问**：介绍一下 https://github.com/obsidian-tasks-group/obsidian-tasks 这个插件。
- **答**：它将笔记中的 Markdown 任务汇总成可筛选、排序和分组的查询结果，完成状态会回写源文件；支持到期日、重复任务等。安装后可用清单项录入任务，用 `tasks` 代码块查看待办；任务通知需借助其他插件。
- **信源**：[一手] [项目 README](https://github.com/obsidian-tasks-group/obsidian-tasks)；[官方查询示例](https://publish.obsidian.md/tasks/Queries/Examples)；[官方通知说明](https://publish.obsidian.md/tasks/Advanced/Notifications)

## 2026-09-24 · Windows 上的 Obsidian vault 如何免费供 iPhone 私有查阅
- **问**：obsidian 免费的发布方案；电脑上的 Obsidian vault，希望在手机上查阅。澄清后为仅自己看，手机是 iPhone；2026-10-10 追问免费多端同步，主要电脑端编辑、iPhone 查看。
- **答**：Windows 与 iPhone 两端安装 Remotely Save，连接同一个个人版 OneDrive 应用文件夹，先备份，再由电脑完成首次上传、手机从同名空 vault 下载；插件基础版免费，Microsoft 账户免费云存储共 5 GB，与其他文件等共享，手机纯查看可选单向增量下载，若需跟随电脑删除则选带删除的下载模式，手机修改不会上传且可能被覆盖。iOS 后台不能自动同步，该方案未经 Obsidian 官方支持，不应让其他服务同时同步该 vault；Windows 上用 iCloud Drive 可能导致文件重复或损坏，手机插件实测与本地网络可达性未核实；此前另有只浏览 Markdown 的备选：GitHub 免费私有仓库，需手动推送，且不能完整呈现 Obsidian 功能。
- **信源**：[一手] [Obsidian 跨设备同步说明](https://obsidian.md/help/sync-notes)；[Remotely Save 中文说明](https://github.com/remotely-save/remotely-save/blob/master/README.zh-cn.md)；[Remotely Save 免费与 PRO 功能对照](https://remotelysave.com/)；[Microsoft 存储配额](https://support.microsoft.com/en-us/onedrive/microsoft-storage-faqs)；[Remotely Save 同步方向设置源码](https://github.com/remotely-save/remotely-save/blob/master/src/settings.ts)；[Remotely Save 同步算法源码](https://github.com/remotely-save/remotely-save/blob/master/pro/src/sync.ts)；历史信源：[GitHub 仓库可见性](https://docs.github.com/en/repositories/creating-and-managing-repositories/about-repositories)
- **更新**：2026-10-10

## 2026-09-26 · Obsidian Git 插件设置与自动同步策略
- **问**：根据八张 Obsidian Git 设置截图，详细讲解如何配置。
- **答**：先确认 Git 仓库、远端、Windows Git Credential Manager 与提交作者；再选择自动策略。分离定时器时，自动提交、推送、拉取独立，截图中的 60／68／75 分钟不保证先拉取再推送；多设备以 Git 同步时，宜关闭分离定时器，使用定期“提交并同步”（提交→拉取→推送），保留错误通知，冲突策略选 Git 默认。若 OneDrive + Remotely Save 已负责跨设备同步，可只在桌面端用 Git 保存历史与备份，避免两个工具同时管理同一文件的双向合并。
- **信源**：[一手] [Obsidian Git 官方入门](https://publish.obsidian.md/git-doc/Getting%20Started)；[官方功能说明](https://publish.obsidian.md/git-doc/Features)；[官方认证说明](https://publish.obsidian.md/git-doc/Authentication)；[官方与其他同步工具协同说明](https://publish.obsidian.md/git-doc/Tips-and-Tricks)；[自动任务源码](https://github.com/Vinzent03/obsidian-git/blob/master/src/automaticsManager.ts)；[设置源码](https://github.com/Vinzent03/obsidian-git/blob/master/src/setting/settings.ts)

## 2026-10-01 · Obsidian 中美化 Mermaid 图表的插件选择
- **问**：obsidian中美化mermaid图表的插件。
- **答**：以多套配色和图表展示为主可先试 Mermaid Boost，它保留标准 Mermaid 代码块并提供缩放、全屏查看和 PNG 导出；希望配色跟随 Obsidian 主题可选 Slick Mermaid，但其默认覆盖 `style`／`classDef` 配色，需要时可关闭。Auto Beautiful Mermaid 用 beautiful-mermaid 美化流程图、时序图、状态图、类图、实体关系图与 XY 图，其他图表回退到原生渲染器，且与 beautiful-mermaid-renderer 冲突；三者均已列入本次核实的 Obsidian 官方社区插件目录，功能依据为作者说明，未在本地 Obsidian 实测。
- **信源**：[一手] [Mermaid Boost 作者 README](https://github.com/dreamfarer-space/obsidian-mermaid-boost)；[Slick Mermaid 作者 README](https://github.com/pasevin/obsidian-slick-mermaid)；[Auto Beautiful Mermaid 作者 README](https://github.com/rxdxxxx/obsidian-auto-beautiful-mermaid)；[Obsidian 官方社区插件目录](https://raw.githubusercontent.com/obsidianmd/obsidian-releases/master/community-plugins.json)
