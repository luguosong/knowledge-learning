# Zotero

## 综述

Zotero API 是程序访问文献库的接口。Zotero Web API v3 访问在线个人或群组库，公开库可匿名读取，私有库及写入须相应权限的 API 密钥；本地 API 由桌面客户端在 `localhost:23119/api/` 提供，读取本机库无需认证，但须在设置中启用，Zotero 10 及以上版本写入需用户授权的本地密钥。二者面向的程序运行位置与数据来源不同，选用时先确定程序运行地点。Translate for Zotero 插件的 DeepLX 是翻译服务选项，与 Zotero 自身 API 分属不同用途。

## 2026-09-26 · Zotero API 是什么
- **问**：ZOTERO API 是什么
- **答**：Zotero API 让程序以 HTTP 请求读取或修改文献条目、分类与标签等资料。Web API v3 面向在线文献库；桌面客户端的本地 API 面向同机程序，可离线读取本地库。私有在线库需要 API 密钥，本地读取需启用本地接口；写入还需要相应授权。
- **信源**：[一手] [Zotero Web API v3 总览](https://www.zotero.org/support/dev/web_api/v3/start)；[Web API 基础与认证](https://www.zotero.org/support/dev/web_api/v3/basics)；[本地 API](https://www.zotero.org/support/dev/web_api/v3/local_api)；[写入请求](https://www.zotero.org/support/dev/web_api/v3/write_requests)
- **更新**：2026-09-26
- **关联**：[[机器翻译#2026-09-26 · 目前免费的翻译 API 接入方案]]
